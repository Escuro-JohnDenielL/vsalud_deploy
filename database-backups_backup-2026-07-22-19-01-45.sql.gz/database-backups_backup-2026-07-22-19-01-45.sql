/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: hayabusa.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `log_id` varchar(255) NOT NULL,
  `admin_id` int NOT NULL,
  `activity_type` varchar(50) NOT NULL,
  `description` text,
  `inquiry_id` int DEFAULT NULL,
  `reserve_id` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `admin_id` (`admin_id`),
  KEY `activity_type` (`activity_type`),
  KEY `time_created` (`created_at`),
  KEY `inquiry_id` (`inquiry_id`),
  KEY `reserve_id` (`reserve_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES
('LOG_6835a0b7730ba2.05778956',14,'logout','Admin \'g ma\' logged out. Session duration: 00:00:00',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-27 11:23:35','2025-06-07 16:30:01'),
('LOG_6835a372926f34.26377368',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-27 11:35:14','2025-06-07 16:30:01'),
('LOG_6835a3c2cb1047.71229428',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-27 11:36:34','2025-06-07 16:30:01'),
('LOG_6835a3d6538701.05196136',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-27 11:36:54','2025-06-07 16:30:01'),
('LOG_6835a47b14c937.13741694',14,'logout','Admin \'g ma\' logged out. Session duration: 00:02:45',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-27 11:39:39','2025-06-07 16:30:01'),
('LOG_6835a5ab7045e0.21456033',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-27 11:44:43','2025-06-07 16:30:01'),
('LOG_6836b6a11220b2.32379875',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-28 07:09:21','2025-06-07 16:30:01'),
('LOG_6836c2e25afc59.80920327',14,'update_status','Admin \'g ma\' changed inquiry #25 status to \'In Progress\'',25,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-28 08:01:38','2025-06-07 16:30:01'),
('LOG_683701daf2bc40.43606339',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-28 12:30:18','2025-06-07 16:30:01'),
('LOG_6838390931de10.01629380',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-29 10:38:01','2025-06-07 16:30:01'),
('LOG_68386e2f95c2b8.65114470',14,'update_status','Admin \'g ma\' changed inquiry #27 status to \'In Progress\'',27,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-29 14:24:47','2025-06-07 16:30:01'),
('LOG_68393882070774.99380679',16,'login','Admin \'TV Five\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 04:48:02','2025-06-07 16:30:01'),
('LOG_6839461947a334.76796397',16,'update_status','Admin \'TV Five\' changed inquiry #26 status to \'Completed\'',26,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:46:01','2025-06-07 16:30:01'),
('LOG_6839461948f472.17537118',16,'create_reservation','Reservation created for inquiry #26 by \'TV Five\'',26,1,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:46:01','2025-06-07 16:30:01'),
('LOG_683946ba8bdf17.74211326',16,'undo_reservation','Admin \'TV Five\' reverted inquiry #26 (deleted reservation #1)',26,1,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:48:42','2025-06-07 16:30:01'),
('LOG_683947c2329d76.94624041',16,'update_status','Admin \'TV Five\' changed inquiry #30 status to \'Pending\'',30,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:06','2025-06-07 16:30:01'),
('LOG_683947c38b96b7.86420779',16,'update_status','Admin \'TV Five\' changed inquiry #31 status to \'Pending\'',31,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:07','2025-06-07 16:30:01'),
('LOG_683947d99fc842.79113190',16,'update_status','Admin \'TV Five\' changed inquiry #14 status to \'Completed\'',14,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:29','2025-06-07 16:30:01'),
('LOG_683947d9a13d04.26223604',16,'create_reservation','Reservation created for inquiry #14 by \'TV Five\'',14,2,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:29','2025-06-07 16:30:01'),
('LOG_683947db2086d2.14936357',16,'update_status','Admin \'TV Five\' changed inquiry #24 status to \'Cancelled\'',24,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:31','2025-06-07 16:30:01'),
('LOG_683947dc78bf54.55761504',16,'update_status','Admin \'TV Five\' changed inquiry #24 status to \'Completed\'',24,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:32','2025-06-07 16:30:01'),
('LOG_683947dc7a2867.02368999',16,'create_reservation','Reservation created for inquiry #24 by \'TV Five\'',24,3,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:32','2025-06-07 16:30:01'),
('LOG_683947df773b89.78509515',16,'update_status','Admin \'TV Five\' changed inquiry #17 status to \'Completed\'',17,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:35','2025-06-07 16:30:01'),
('LOG_683947df785792.42097679',16,'create_reservation','Reservation created for inquiry #17 by \'TV Five\'',17,4,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:35','2025-06-07 16:30:01'),
('LOG_683947e11f7402.54688492',16,'update_status','Admin \'TV Five\' changed inquiry #20 status to \'Completed\'',20,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:37','2025-06-07 16:30:01'),
('LOG_683947e12149c1.68314083',16,'create_reservation','Reservation created for inquiry #20 by \'TV Five\'',20,5,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:37','2025-06-07 16:30:01'),
('LOG_683947e2ae3ce2.02505596',16,'update_status','Admin \'TV Five\' changed inquiry #7 status to \'Completed\'',7,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:38','2025-06-07 16:30:01'),
('LOG_683947e2af8633.73054596',16,'create_reservation','Reservation created for inquiry #7 by \'TV Five\'',7,6,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:38','2025-06-07 16:30:01'),
('LOG_683947e4669c02.35787151',16,'update_status','Admin \'TV Five\' changed inquiry #18 status to \'Completed\'',18,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:40','2025-06-07 16:30:01'),
('LOG_683947e467e326.64625647',16,'create_reservation','Reservation created for inquiry #18 by \'TV Five\'',18,7,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-05-30 05:53:40','2025-06-07 16:30:01'),
('LOG_683da2f43f5c92.29258809',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36','2025-06-02 13:11:16','2025-06-07 16:30:01'),
('LOG_6841b3e9f3c3f3.19843225',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-05 15:12:41','2025-06-07 16:30:01'),
('LOG_68427be68a6a27.70784955',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-06 05:25:58','2025-06-07 16:30:01'),
('LOG_68427c0a154605.46212096',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-06 05:26:34','2025-06-07 16:30:01'),
('LOG_6844593261a404.13392553',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'0','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-07 15:22:26','2025-06-07 16:30:01'),
('LOG_684872f0aebb67.79469734',14,'login','Admin logged in successfully',NULL,NULL,NULL,NULL,'2025-06-10 10:01:20','2025-06-10 10:01:20'),
('LOG_684872faf316e8.29617845',14,'login','Admin logged in successfully',NULL,NULL,NULL,NULL,'2025-06-10 10:01:30','2025-06-10 10:01:30'),
('LOG_6848742289c159.56707309',14,'logout','Admin \'g ma\' logged out. Session duration: 00:00:00',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:06:26','2025-06-10 10:06:26'),
('LOG_684876ebad39b4.68254837',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:18:19','2025-06-10 10:18:19'),
('LOG_68487701c21151.25447880',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:18:41','2025-06-10 10:18:41'),
('LOG_68487716218706.98935746',14,'logout','Admin \'g ma\' logged out. Session duration: 00:00:20',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:19:02','2025-06-10 10:19:02'),
('LOG_6848790ce77040.93478292',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:27:24','2025-06-10 10:27:24'),
('LOG_6848791c65ff02.11205736',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:27:40','2025-06-10 10:27:40'),
('LOG_68487923004c52.80659969',14,'logout','Admin \'g ma\' logged out. Session duration: 00:00:06',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:27:47','2025-06-10 10:27:47'),
('LOG_68487dba2cec47.67952032',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-10 10:47:22','2025-06-10 10:47:22'),
('LOG_68493f13920051.41126765',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-11 00:32:19','2025-06-11 00:32:19'),
('LOG_684951de59f731.93234490',14,'Created Inquiry','Admin g ma created inquiry #47',47,NULL,NULL,NULL,'2025-06-11 01:52:30','2025-06-11 01:52:30'),
('LOG_6849c7a8baf8c2.84016574',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-11 10:15:04','2025-06-11 10:15:04'),
('LOG_684a313ac1ecf8.55841028',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-11 17:45:30','2025-06-11 17:45:30'),
('LOG_684a788ddaeee9.78438815',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-11 22:49:49','2025-06-11 22:49:49'),
('LOG_684a83d5592567.04567180',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-11 23:37:57','2025-06-11 23:37:57'),
('LOG_684a934b63ca01.72430514',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:43:55','2025-06-12 00:43:55'),
('LOG_684a934ccf6ea6.08562352',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:43:56','2025-06-12 00:43:56'),
('LOG_684a936805ab12.62590027',14,'System Action','Invalid phone format entered: 2115-616-165',NULL,NULL,NULL,NULL,'2025-06-12 00:44:24','2025-06-12 00:44:24'),
('LOG_684a936962dd96.98271774',14,'System Action','Invalid phone format entered: 2115-616-165',NULL,NULL,NULL,NULL,'2025-06-12 00:44:25','2025-06-12 00:44:25'),
('LOG_684a936aac2e77.63506876',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:44:26','2025-06-12 00:44:26'),
('LOG_684a9381dbe998.14338835',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:44:49','2025-06-12 00:44:49'),
('LOG_684a93a1f3d402.99112615',14,'Profile Change','Name: \"\" → \"John Mayer\"; Email: \"haynako@gmail.com\" → \"jmayer@gmail.com\"; Phone: \"21156161654\" → \"0946-572-3981\"; Username: \"haynako\" → \"ADMIN John\"',NULL,NULL,NULL,NULL,'2025-06-12 00:45:21','2025-06-12 00:45:21'),
('LOG_684a94e2507a42.74286631',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:50:42','2025-06-12 00:50:42'),
('LOG_684a94e897aca0.83638418',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:50:48','2025-06-12 00:50:48'),
('LOG_684a95065a5f06.31676814',14,'Profile Change','Name: \"\" → \"John Doe\"; Email: \"haynako@gmail.com\" → \"doejohn@gmail.com\"; Phone: \"21156161654\" → \"0948-864-2607\"; Username: \"haynako\" → \"ADMIN John\"',NULL,NULL,NULL,NULL,'2025-06-12 00:51:18','2025-06-12 00:51:18'),
('LOG_684a95af5aaa49.88182566',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:54:07','2025-06-12 00:54:07'),
('LOG_684a95b2a783d5.35444530',14,'Profile Change','No changes were made to profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:54:10','2025-06-12 00:54:10'),
('LOG_684a9628f009d2.45912541',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:56:08','2025-06-12 00:56:08'),
('LOG_684a964f660561.17890064',14,'Profile Change','Name: \"\" → \"John Doe\"; Email: \"haynako@gmail.com\" → \"jdoe@gmail.com\"; Phone: \"21156161654\" → \"0948-864-2607\"; Username: \"haynako\" → \"ADMIN John\"',NULL,NULL,NULL,NULL,'2025-06-12 00:56:47','2025-06-12 00:56:47'),
('LOG_684a96758decd9.68182078',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:57:25','2025-06-12 00:57:25'),
('LOG_684a96816e4759.74482552',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:57:37','2025-06-12 00:57:37'),
('LOG_684a969567a603.35283969',14,'Profile Change','Name: \"\" → \"John Doe\"; Email: \"haynako@gmail.com\" → \"jdoe@gmail.com\"; Phone: \"21156161654\" → \"0948-864-2607\"; Username: \"haynako\" → \"ADMIN John\"',NULL,NULL,NULL,NULL,'2025-06-12 00:57:57','2025-06-12 00:57:57'),
('LOG_684a96f1d2b108.44630521',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 00:59:29','2025-06-12 00:59:29'),
('LOG_684a97073818c3.89027849',14,'Profile Change','Name: \"\" → \"John Doe\"; Email: \"haynako@gmail.com\" → \"jdoe@gmail.com\"; Phone: \"21156161654\" → \"0948-864-2607\"; Username: \"haynako\" → \"ADMIN John\"',NULL,NULL,NULL,NULL,'2025-06-12 00:59:51','2025-06-12 00:59:51'),
('LOG_684a98379e3862.20254363',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 01:04:55','2025-06-12 01:04:55'),
('LOG_684a9846069831.22932456',14,'Profile Change','Name: \"\" → \"John Doe\"; Email: \"haynako@gmail.com\" → \"jdoe@gmail.com\"; Phone: \"21156161654\" → \"0948-864-2607\"; Username: \"haynako\" → \"ADMIN John\"',NULL,NULL,NULL,NULL,'2025-06-12 01:05:10','2025-06-12 01:05:10'),
('LOG_684a9d81bacb39.86759472',14,'login','Admin \'g ma\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 01:27:29','2025-06-12 01:27:29'),
('LOG_684a9d9672a6e2.67504985',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 01:27:50','2025-06-12 01:27:50'),
('LOG_684a9dc212c8b5.41823357',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 01:28:34','2025-06-12 01:28:34'),
('LOG_684a9dcb099886.95719893',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 01:28:43','2025-06-12 01:28:43'),
('LOG_684a9dfb962d98.61893663',14,'Profile Change','Name: \"g ma\" → \"John Doe\"; Email: \"haynako@gmail.com\" → \"jdoe@gmail.com\"; Phone: \"21156161654\" → \"0948-864-2607\"',NULL,NULL,NULL,NULL,'2025-06-12 01:29:31','2025-06-12 01:29:31'),
('LOG_684aa637328ee3.66706893',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:04:39','2025-06-12 02:04:39'),
('LOG_684aa653057c64.04065894',14,'Security','Admin account password updated',NULL,NULL,NULL,NULL,'2025-06-12 02:05:07','2025-06-12 02:05:07'),
('LOG_684aa66e6e7ed0.94755900',14,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2025-06-12 02:05:34','2025-06-12 02:05:34'),
('LOG_684aa66ea5df09.53239179',14,'logout','Admin \'John Doe\' logged out. Session duration: 00:38:04',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 02:05:34','2025-06-12 02:05:34'),
('LOG_684aa6999d5a42.03349316',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 02:06:17','2025-06-12 02:06:17'),
('LOG_684aa983bbff55.81029679',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:18:43','2025-06-12 02:18:43'),
('LOG_684aabd8a0fbc5.75351155',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:28:40','2025-06-12 02:28:40'),
('LOG_684aaf834eb323.83629583',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:44:19','2025-06-12 02:44:19'),
('LOG_684aaf9c333008.22749827',14,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2025-06-12 02:44:44','2025-06-12 02:44:44'),
('LOG_684aaf9c8f0c87.36131049',14,'logout','Admin \'John Doe\' logged out. Session duration: 00:38:26',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 02:44:44','2025-06-12 02:44:44'),
('LOG_684aafaa303966.39041854',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 02:44:58','2025-06-12 02:44:58'),
('LOG_684aafaf287027.67941860',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:45:03','2025-06-12 02:45:03'),
('LOG_684aafcb1d2843.38132830',14,'Security','JS fetch exception thrown',NULL,NULL,NULL,NULL,'2025-06-12 02:45:31','2025-06-12 02:45:31'),
('LOG_684ab20b6e42c2.30399624',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:55:07','2025-06-12 02:55:07'),
('LOG_684ab219207654.84862285',14,'Security','JS fetch exception thrown',NULL,NULL,NULL,NULL,'2025-06-12 02:55:21','2025-06-12 02:55:21'),
('LOG_684ab2891894e8.51589280',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:57:13','2025-06-12 02:57:13'),
('LOG_684ab296c96ad0.31027539',14,'Security','JS fetch exception thrown',NULL,NULL,NULL,NULL,'2025-06-12 02:57:26','2025-06-12 02:57:26'),
('LOG_684ab2fdbf37a0.84875745',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 02:59:09','2025-06-12 02:59:09'),
('LOG_684ab328ebbd00.11651581',14,'Security','JS fetch exception thrown',NULL,NULL,NULL,NULL,'2025-06-12 02:59:52','2025-06-12 02:59:52'),
('LOG_684ab45ab5e555.11911632',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 03:04:58','2025-06-12 03:04:58'),
('LOG_684ab46916ffd8.49601882',14,'Security','Admin account password updated',NULL,NULL,NULL,NULL,'2025-06-12 03:05:13','2025-06-12 03:05:13'),
('LOG_684ab478e82853.95682440',14,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2025-06-12 03:05:28','2025-06-12 03:05:28'),
('LOG_684ab47953d1c7.54127262',14,'logout','Admin \'John Doe\' logged out. Session duration: 00:20:31',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 03:05:29','2025-06-12 03:05:29'),
('LOG_684ab487059fd9.43522887',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 03:05:43','2025-06-12 03:05:43'),
('LOG_684ab701298617.63419044',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:16:17','2025-06-12 03:16:17'),
('LOG_684ab711ca8617.05782137',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 03:16:33','2025-06-12 03:16:33'),
('LOG_684ab7d4223748.97663725',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:19:48','2025-06-12 03:19:48'),
('LOG_684ab7d7d3bca1.40470216',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 03:19:51','2025-06-12 03:19:51'),
('LOG_684ab7f9436c07.52083657',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:20:25','2025-06-12 03:20:25'),
('LOG_684ab7fdbc97d8.61859645',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 03:20:29','2025-06-12 03:20:29'),
('LOG_684ab800abd4e2.49821820',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 03:20:32','2025-06-12 03:20:32'),
('LOG_684ab804859b91.47935871',14,'System Action','Cancelled profile editing without saving',NULL,NULL,NULL,NULL,'2025-06-12 03:20:36','2025-06-12 03:20:36'),
('LOG_684ab84ed66878.57171399',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:21:50','2025-06-12 03:21:50'),
('LOG_684ab852c7d780.84464223',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:21:54','2025-06-12 03:21:54'),
('LOG_684ab91a581044.72972749',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 03:25:14','2025-06-12 03:25:14'),
('LOG_684ab91d69c136.06802671',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 03:25:17','2025-06-12 03:25:17'),
('LOG_684ab91e8d5fa8.97625267',14,'Security','Cancelled password change without saving',NULL,NULL,NULL,NULL,'2025-06-12 03:25:18','2025-06-12 03:25:18'),
('LOG_684ab91f7e93d5.24882390',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:25:19','2025-06-12 03:25:19'),
('LOG_684ab926c41114.03509523',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 03:25:26','2025-06-12 03:25:26'),
('LOG_684aba863fa075.70508627',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 03:31:18','2025-06-12 03:31:18'),
('LOG_684aba91246855.78316644',14,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-12 03:31:29','2025-06-12 03:31:29'),
('LOG_684aba93df2728.04840486',14,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-12 03:31:31','2025-06-12 03:31:31'),
('LOG_684aba95ea6764.43416996',14,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-12 03:31:33','2025-06-12 03:31:33'),
('LOG_684aecb4709509.34624192',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 07:05:24','2025-06-12 07:05:24'),
('LOG_684b2151e05f93.38795660',14,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2025-06-12 10:49:53','2025-06-12 10:49:53'),
('LOG_684b21522130b6.02544817',14,'logout','Admin \'John Doe\' logged out. Session duration: 03:44:29',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 10:49:54','2025-06-12 10:49:54'),
('LOG_684b245589a2a5.04441720',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 11:02:45','2025-06-12 11:02:45'),
('LOG_684b27a7468e77.52599698',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 11:16:55','2025-06-12 11:16:55'),
('LOG_684b28be2f5744.32508707',18,'login','Admin \'Admin Admin\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 11:21:34','2025-06-12 11:21:34'),
('LOG_684b2bb1aae590.93339084',18,'Created Inquiry','Admin Admin Admin created inquiry #52',52,NULL,NULL,NULL,'2025-06-12 11:34:09','2025-06-12 11:34:09'),
('LOG_684b3153d9ab93.32188584',18,'Created Inquiry','Admin Admin Admin created inquiry #53',53,NULL,NULL,NULL,'2025-06-12 11:58:11','2025-06-12 11:58:11'),
('LOG_684b31bc18f4a6.94394249',18,'Created Inquiry','Admin Admin Admin created inquiry #54',54,NULL,NULL,NULL,'2025-06-12 11:59:56','2025-06-12 11:59:56'),
('LOG_684b571fe85d97.77398520',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-12 14:39:27','2025-06-12 14:39:27'),
('LOG_6850fa460ecd87.90741190',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-16 21:16:54','2025-06-16 21:16:54'),
('LOG_6850fc2fdbcbc0.66077341',14,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2025-06-16 21:25:03','2025-06-16 21:25:03'),
('LOG_6850fc306aa4e8.32854975',14,'logout','Admin \'John Doe\' logged out. Session duration: 00:08:10',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-16 21:25:04','2025-06-16 21:25:04'),
('LOG_6850fcbad6ab22.26134301',14,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-16 21:27:22','2025-06-16 21:27:22'),
('LOG_6852b825b14257.92177344',16,'login','Admin \'TV Five\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-18 04:59:17','2025-06-18 04:59:17'),
('LOG_68537fb92fd6c3.69757811',19,'login','Admin \'Marc AdminGasta\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-18 19:10:49','2025-06-18 19:10:49'),
('LOG_6853ab018a1e52.54950953',20,'login','Admin \'Jack Marston\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-18 22:15:29','2025-06-18 22:15:29'),
('LOG_6853cc95563ac0.18329237',21,'login','Admin \'Daph Ney\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-19 00:38:45','2025-06-19 00:38:45'),
('LOG_685bd10cc88190.55946189',21,'login','Admin \'Daph Ney\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-25 02:35:56','2025-06-25 02:35:56'),
('LOG_685bd7ca51c096.96559040',21,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-25 03:04:42','2025-06-25 03:04:42'),
('LOG_685bd7cb628e78.16460083',21,'Profile Change','Changed to: Professional',NULL,NULL,NULL,NULL,'2025-06-25 03:04:43','2025-06-25 03:04:43'),
('LOG_685bd7e34d48c3.34299770',21,'System Action','All admin history entries were deleted',NULL,NULL,NULL,NULL,'2025-06-25 03:05:07','2025-06-25 03:05:07'),
('LOG_685bd7e5b13924.26292833',21,'System Action','All admin history entries were deleted',NULL,NULL,NULL,NULL,'2025-06-25 03:05:09','2025-06-25 03:05:09'),
('LOG_685bd7f974c988.82082035',21,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2025-06-25 03:05:29','2025-06-25 03:05:29'),
('LOG_685bd7ff986da7.67833353',21,'System Action','Cancelled profile editing without saving',NULL,NULL,NULL,NULL,'2025-06-25 03:05:35','2025-06-25 03:05:35'),
('LOG_685bd801a3f8f2.84949898',21,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2025-06-25 03:05:37','2025-06-25 03:05:37'),
('LOG_685bd806dd7279.51237033',21,'Security','Cancelled password change without saving',NULL,NULL,NULL,NULL,'2025-06-25 03:05:42','2025-06-25 03:05:42'),
('LOG_685bd80c909f80.43145321',21,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2025-06-25 03:05:48','2025-06-25 03:05:48'),
('LOG_685bd8274b6e84.77474879',21,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2025-06-25 03:06:15','2025-06-25 03:06:15'),
('LOG_685bd8277efab7.87011329',21,'logout','Admin \'Daph Ney\' logged out. Session duration: 00:30:18',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','2025-06-25 03:06:15','2025-06-25 03:06:15'),
('LOG_6a45d4e17fba98.77127977',22,'login','Admin \'Juan Tamad\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-01 19:02:57','2026-07-01 19:02:57'),
('LOG_6a46b1f856e071.20054277',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'136.158.33.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 10:46:16','2026-07-02 10:46:16'),
('LOG_6a46b22e467825.94553432',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.126.0 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36','2026-07-02 10:47:10','2026-07-02 10:47:10'),
('LOG_6a46b26517a912.59682411',23,'System Action','Opened image selection modal',NULL,NULL,NULL,NULL,'2026-07-02 10:48:05','2026-07-02 10:48:05'),
('LOG_6a46b26615daa8.62152497',23,'Profile Change','Changed to: Casual',NULL,NULL,NULL,NULL,'2026-07-02 10:48:06','2026-07-02 10:48:06'),
('LOG_6a46b6b3cf52f6.28710275',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.126.0 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36','2026-07-02 11:06:27','2026-07-02 11:06:27'),
('LOG_6a46c628330224.82168013',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'136.158.33.196','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-02 12:12:24','2026-07-02 12:12:24'),
('LOG_6a4721361f2064.90431157',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.126.0 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36','2026-07-02 18:40:54','2026-07-02 18:40:54'),
('LOG_6a472368d6a000.21935490',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.126.0 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36','2026-07-02 18:50:16','2026-07-02 18:50:16'),
('LOG_6a4726cf471544.99652387',24,'login','Admin \'Andrea Donatos\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 19:04:47','2026-07-02 19:04:47'),
('LOG_6a4726f63701c8.32530716',24,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 19:05:26','2026-07-02 19:05:26'),
('LOG_6a472710c423a5.65253038',24,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 19:05:52','2026-07-02 19:05:52'),
('LOG_6a47271fe19a14.90491946',24,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-02 19:06:07','2026-07-02 19:06:07'),
('LOG_6a47272c9e6323.83829532',24,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 19:06:20','2026-07-02 19:06:20'),
('LOG_6a472753ede814.92494508',24,'Security','Current password is incorrect.',NULL,NULL,NULL,NULL,'2026-07-02 19:06:59','2026-07-02 19:06:59'),
('LOG_6a47276cc32788.73368756',24,'Security','Current password is incorrect.',NULL,NULL,NULL,NULL,'2026-07-02 19:07:24','2026-07-02 19:07:24'),
('LOG_6a472778edc7b9.29589791',24,'Security','Admin account password updated',NULL,NULL,NULL,NULL,'2026-07-02 19:07:36','2026-07-02 19:07:36'),
('LOG_6a472ab6e37a69.00814074',24,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-02 19:21:26','2026-07-02 19:21:26'),
('LOG_6a472acbd3aed2.61908088',24,'System Action','Invalid phone format entered: 09090090909',NULL,NULL,NULL,NULL,'2026-07-02 19:21:47','2026-07-02 19:21:47'),
('LOG_6a472bf38f2fe5.08361840',24,'login','Admin \'Andrea Donatos\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 19:26:43','2026-07-02 19:26:43'),
('LOG_6a472d510558e1.10968433',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 19:32:33','2026-07-02 19:32:33'),
('LOG_6a472ef6857347.57121020',24,'login','Admin \'Andrea Donatos\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 19:39:34','2026-07-02 19:39:34'),
('LOG_6a4736b18268c7.07253761',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 20:12:33','2026-07-02 20:12:33'),
('LOG_6a47371e4f8c64.43851971',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 20:14:22','2026-07-02 20:14:22'),
('LOG_6a4748d01be869.80837169',25,'System Action','All admin history entries were deleted',NULL,NULL,NULL,NULL,'2026-07-02 21:29:52','2026-07-02 21:29:52'),
('LOG_6a47498bb37338.90591125',25,'System Action','All admin history entries were deleted',NULL,NULL,NULL,NULL,'2026-07-02 21:32:59','2026-07-02 21:32:59'),
('LOG_6a474d29482551.58250078',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 21:48:25','2026-07-02 21:48:25'),
('LOG_6a474d2dd30331.15969458',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 21:48:29','2026-07-02 21:48:29'),
('LOG_6a474f13cc7817.39374326',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 21:56:35','2026-07-02 21:56:35'),
('LOG_6a47516f4ef535.55332389',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:06:39','2026-07-02 22:06:39'),
('LOG_6a47548de2f842.46612388',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:19:57','2026-07-02 22:19:57'),
('LOG_6a4754a09b4ba9.16305637',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:20:16','2026-07-02 22:20:16'),
('LOG_6a4754af961223.28622962',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:20:31','2026-07-02 22:20:31'),
('LOG_6a475528b8ac70.78694020',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:22:32','2026-07-02 22:22:32'),
('LOG_6a47553bac81b3.79469334',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:22:51','2026-07-02 22:22:51'),
('LOG_6a475752d3f207.92815860',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:31:46','2026-07-02 22:31:46'),
('LOG_6a47589bb28163.24862558',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-02 22:37:15','2026-07-02 22:37:15'),
('LOG_6a4759517151e0.40944048',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 22:40:17','2026-07-02 22:40:17'),
('LOG_6a475954a74711.86288373',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-02 22:40:20','2026-07-02 22:40:20'),
('LOG_6a475958480105.56373012',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-02 22:40:24','2026-07-02 22:40:24'),
('LOG_6a475d15ecb097.72874003',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 22:56:21','2026-07-02 22:56:21'),
('LOG_6a48e995be59b4.57730916',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:08:05','2026-07-04 03:08:05'),
('LOG_6a48eee9649b33.62012132',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:30:49','2026-07-04 03:30:49'),
('LOG_6a48f02f4c2695.50277617',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:36:15','2026-07-04 03:36:15'),
('LOG_6a48f036e3e6f3.65298902',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:36:22','2026-07-04 03:36:22'),
('LOG_6a48f1835eecc3.14301070',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:41:55','2026-07-04 03:41:55'),
('LOG_6a48f1eeee5631.70477274',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:43:42','2026-07-04 03:43:42'),
('LOG_6a48f38adf19b9.69788592',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:50:34','2026-07-04 03:50:34'),
('LOG_6a48f47a71c5a0.67852319',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:54:34','2026-07-04 03:54:34'),
('LOG_6a48f494d932a4.72657629',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:55:00','2026-07-04 03:55:00'),
('LOG_6a48f59e91b639.90887313',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 03:59:26','2026-07-04 03:59:26'),
('LOG_6a48f61ea5e0b6.41834496',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:01:34','2026-07-04 04:01:34'),
('LOG_6a48f92d34f5c5.11843682',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:14:37','2026-07-04 04:14:37'),
('LOG_6a48f967ef1c66.35384614',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:15:35','2026-07-04 04:15:35'),
('LOG_6a48f9750e3007.68245018',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:15:49','2026-07-04 04:15:49'),
('LOG_6a48f9878acfd2.02834183',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:16:07','2026-07-04 04:16:07'),
('LOG_6a4903498f2f39.99669285',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:57:45','2026-07-04 04:57:45'),
('LOG_6a490a6122fe89.32224809',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 05:28:01','2026-07-04 05:28:01'),
('LOG_6a490a8b369683.98436556',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 05:28:43','2026-07-04 05:28:43'),
('LOG_6a4918f9de85b6.00595216',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.126.0 Chrome/148.0.7778.97 Electron/42.2.0 Safari/537.36','2026-07-04 06:30:17','2026-07-04 06:30:17'),
('LOG_6a491948d2ba11.86113558',25,'Cancellation Approved','Admin John Doe approved cancellation request #1 for reservation #9',51,9,NULL,NULL,'2026-07-04 06:31:36','2026-07-04 06:31:36'),
('LOG_6a49e61e6400f6.54878315',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 21:05:34','2026-07-04 21:05:34'),
('LOG_6a4a51cb8d9c12.86987046',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 04:44:59','2026-07-05 04:44:59'),
('LOG_6a4a58255d86b0.55126510',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 05:12:05','2026-07-05 05:12:05'),
('LOG_6a4a5afbe11116.07747363',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 05:24:11','2026-07-05 05:24:11'),
('LOG_6a4a6017856295.84672029',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 05:45:59','2026-07-05 05:45:59'),
('LOG_6a4a60221ab668.93359458',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 05:46:10','2026-07-05 05:46:10'),
('LOG_6a4a602abb0b57.83380662',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 05:46:18','2026-07-05 05:46:18'),
('LOG_6a4a66cb7e94d9.59417990',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 06:14:35','2026-07-05 06:14:35'),
('LOG_6a4a66dc73fe99.69521094',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 06:14:52','2026-07-05 06:14:52'),
('LOG_6a4a66f118dd99.64376340',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 06:15:13','2026-07-05 06:15:13'),
('LOG_6a4e4813248ba5.02341478',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-08 04:52:35','2026-07-08 04:52:35'),
('LOG_6a4e49a31e97f6.53524394',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-08 04:59:15','2026-07-08 04:59:15'),
('LOG_6a513c0bcfdcb6.89438559',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 10:38:03','2026-07-10 10:38:03'),
('LOG_6a513c128b97e8.38734159',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 10:38:10','2026-07-10 10:38:10'),
('LOG_6a513c305fbe91.25330894',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-10 10:38:40','2026-07-10 10:38:40'),
('LOG_6a513c3b327e02.22662393',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-10 10:38:51','2026-07-10 10:38:51'),
('LOG_6a513c455f4028.75040673',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-10 10:39:01','2026-07-10 10:39:01'),
('LOG_6a51511b9365d3.85115828',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-10 12:07:55','2026-07-10 12:07:55'),
('LOG_6a51512395a7c0.95334340',25,'Security','Password reset code sent to admin email',NULL,NULL,NULL,NULL,'2026-07-10 12:08:03','2026-07-10 12:08:03'),
('LOG_6a51512d881965.18195596',25,'Security','Cancelled password change without saving',NULL,NULL,NULL,NULL,'2026-07-10 12:08:13','2026-07-10 12:08:13'),
('LOG_6a5153214ce3d9.59647819',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:16:33','2026-07-10 12:16:33'),
('LOG_6a51532fb23e52.61803225',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:16:47','2026-07-10 12:16:47'),
('LOG_6a51535dd40675.81437528',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:17:33','2026-07-10 12:17:33'),
('LOG_6a5156a303b4a8.86402432',0,'failed_login','Failed login attempt for email \'admin123@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:31:31','2026-07-10 12:31:31'),
('LOG_6a5156aa71f6f9.63541324',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:31:38','2026-07-10 12:31:38'),
('LOG_6a5156b280ce47.85698923',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:31:46','2026-07-10 12:31:46'),
('LOG_6a5156b7b069a0.24394403',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:31:51','2026-07-10 12:31:51'),
('LOG_6a5156bf97f475.29434948',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:31:59','2026-07-10 12:31:59'),
('LOG_6a5156c77e5f66.80832110',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:32:07','2026-07-10 12:32:07'),
('LOG_6a5156cc0263e4.85495040',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:32:12','2026-07-10 12:32:12'),
('LOG_6a5156d31fd421.34654533',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:32:19','2026-07-10 12:32:19'),
('LOG_6a5156d6181b72.85848189',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:32:22','2026-07-10 12:32:22'),
('LOG_6a5157d1e67019.28846404',3,'login','Test',NULL,NULL,'127.0.0.1','test','2026-07-10 12:36:33','2026-07-10 12:36:33'),
('LOG_6a5158162acb19.44618867',0,'failed_login','Failed login attempt for email \'test@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:37:42','2026-07-10 12:37:42'),
('LOG_6a51582a198173.42697338',3,'login','Admin \'A A\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:38:02','2026-07-10 12:38:02'),
('LOG_6a5158390b4866.80777969',3,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2026-07-10 12:38:17','2026-07-10 12:38:17'),
('LOG_6a5158394ff010.34602273',3,'logout','Admin \'A A\' logged out. Session duration: 00:00:15',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:38:17','2026-07-10 12:38:17'),
('LOG_6a51584163a655.24535278',3,'login','Admin \'A A\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:38:25','2026-07-10 12:38:25'),
('LOG_6a515852471f94.58316494',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:38:42','2026-07-10 12:38:42'),
('LOG_6a5158ee5338b2.22901502',3,'logout','Admin \'A A\' logged out. Session duration: 00:02:52',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:41:18','2026-07-10 12:41:18'),
('LOG_6a515909ea33a4.34511833',4,'login','Admin \'B B\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:41:45','2026-07-10 12:41:45'),
('LOG_6a51596e4b1d01.70729821',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:43:26','2026-07-10 12:43:26'),
('LOG_6a5159761f2211.87695172',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:43:34','2026-07-10 12:43:34'),
('LOG_6a5159c21c0975.92134582',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:44:50','2026-07-10 12:44:50'),
('LOG_6a5159db5fd7d6.12223390',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:45:15','2026-07-10 12:45:15'),
('LOG_6a5159fb728b38.91667371',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:45:47','2026-07-10 12:45:47'),
('LOG_6a515a7c3f5909.99650745',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:47:56','2026-07-10 12:47:56'),
('LOG_6a515a86d338c5.14860270',4,'login','Admin \'B B\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:48:06','2026-07-10 12:48:06'),
('LOG_6a515a9587e163.83510273',4,'login','Admin \'B B\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:48:21','2026-07-10 12:48:21'),
('LOG_6a515a9f85ab21.47249756',4,'Logout','Admin logged out of the system',NULL,NULL,NULL,NULL,'2026-07-10 12:48:31','2026-07-10 12:48:31'),
('LOG_6a515a9fccf583.47442227',4,'logout','Admin \'B B\' logged out. Session duration: 00:00:10',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:48:31','2026-07-10 12:48:31'),
('LOG_6a515aa2ddea72.56391719',3,'login','Admin \'A A\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:48:34','2026-07-10 12:48:34'),
('LOG_6a515bc74ba209.59789117',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:53:27','2026-07-10 12:53:27'),
('LOG_6a515bd19efad0.39604875',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:53:37','2026-07-10 12:53:37'),
('LOG_6a515bdcc52d49.45523194',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:53:48','2026-07-10 12:53:48'),
('LOG_6a515c19c10644.85507183',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:54:49','2026-07-10 12:54:49'),
('LOG_6a515c1e10cf77.73961652',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:54:54','2026-07-10 12:54:54'),
('LOG_6a515c247ad6c5.36169763',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:55:00','2026-07-10 12:55:00'),
('LOG_6a515c27caadb0.68545874',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:55:03','2026-07-10 12:55:03'),
('LOG_6a515c2f626c75.89851823',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 12:55:11','2026-07-10 12:55:11'),
('LOG_6a515cccc1e3f3.26887113',4,'login','Admin \'B B\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:57:48','2026-07-10 12:57:48'),
('LOG_6a515cd0172805.36358782',4,'login','Admin \'B B\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-10 12:57:52','2026-07-10 12:57:52'),
('LOG_6a515d88ed3a24.17077750',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:00:56','2026-07-10 13:00:56'),
('LOG_6a515d909ae588.21394747',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:01:04','2026-07-10 13:01:04'),
('LOG_6a515db4ce5b64.98677998',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:01:40','2026-07-10 13:01:40'),
('LOG_6a515dbb7e13f1.40673010',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:01:47','2026-07-10 13:01:47'),
('LOG_6a515dd9a9a627.74221710',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:02:17','2026-07-10 13:02:17'),
('LOG_6a515de0d89a05.52939890',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:02:24','2026-07-10 13:02:24'),
('LOG_6a515df0756290.20287703',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:02:40','2026-07-10 13:02:40'),
('LOG_6a515df7944728.61770779',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:02:47','2026-07-10 13:02:47'),
('LOG_6a515dff6ae446.09401247',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:02:55','2026-07-10 13:02:55'),
('LOG_6a515e04835987.70054066',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:03:00','2026-07-10 13:03:00'),
('LOG_6a515f8cba8f82.85988664',23,'logout','Admin \'John Deniel\' logged out. Session duration: 00:06:32',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:32','2026-07-10 13:09:32'),
('LOG_6a515f8f8baa00.62087917',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:35','2026-07-10 13:09:35'),
('LOG_6a515f942bfdf6.34061332',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:00:04',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:40','2026-07-10 13:09:40'),
('LOG_6a515f96b583c6.08589230',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:42','2026-07-10 13:09:42'),
('LOG_6a515f99284109.29424506',26,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:02',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:45','2026-07-10 13:09:45'),
('LOG_6a515f9c500e83.31287388',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:48','2026-07-10 13:09:48'),
('LOG_6a515f9dcd6967.66057580',26,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:01',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:49','2026-07-10 13:09:49'),
('LOG_6a515fa21d44b4.11843300',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:09:54','2026-07-10 13:09:54'),
('LOG_6a515fa996c311.37022766',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:10:01','2026-07-10 13:10:01'),
('LOG_6a515ff7b76ac1.11128279',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:11:19','2026-07-10 13:11:19'),
('LOG_6a516053e64f18.01128704',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:01:32',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:12:51','2026-07-10 13:12:51'),
('LOG_6a51605760ba27.96105785',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:12:55','2026-07-10 13:12:55'),
('LOG_6a51605a750901.19581488',26,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:03',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:12:58','2026-07-10 13:12:58'),
('LOG_6a51605d0eb164.29427222',23,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:13:01','2026-07-10 13:13:01'),
('LOG_6a516066203aa5.54659348',23,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:09',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:13:10','2026-07-10 13:13:10'),
('LOG_6a5160692781b7.36295829',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:13:13','2026-07-10 13:13:13'),
('LOG_6a51681cba7b89.84516403',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:32:51',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:46:04','2026-07-10 13:46:04'),
('LOG_6a51681f93dba1.50784119',26,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 13:46:07','2026-07-10 13:46:07'),
('LOG_6a537f1e7e7e60.34284662',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 03:48:46','2026-07-12 03:48:46'),
('LOG_6a53841fe1aa08.53421691',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:21:21',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 04:10:07','2026-07-12 04:10:07'),
('LOG_6a53842c8e26e2.54615117',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 04:10:20','2026-07-12 04:10:20'),
('LOG_6a538513376ac6.40072834',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-12 04:14:11','2026-07-12 04:14:11'),
('LOG_6a53853e300012.64572284',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-12 04:14:54','2026-07-12 04:14:54'),
('LOG_6a53885273c361.41508568',0,'failed_login','Failed login attempt for email \'coheredit@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:28:02','2026-07-12 04:28:02'),
('LOG_6a538868afe4b3.45191624',0,'failed_login','Failed login attempt for email \'jdoe@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:28:24','2026-07-12 04:28:24'),
('LOG_6a53890bddece3.24923432',0,'failed_login','Failed login attempt for email \'test@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:31:07','2026-07-12 04:31:07'),
('LOG_6a5389664755a7.10219095',0,'failed_login','Failed login attempt for email \'test@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:32:38','2026-07-12 04:32:38'),
('LOG_6a53896ab0e002.47847430',0,'failed_login','Failed login attempt for email \'testing@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:32:42','2026-07-12 04:32:42'),
('LOG_6a53898b66ad11.05248877',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:15','2026-07-12 04:33:15'),
('LOG_6a538990240818.60876807',0,'failed_login','Failed login attempt for email \'coheredit@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:20','2026-07-12 04:33:20'),
('LOG_6a53899123c368.88120006',0,'failed_login','Failed login attempt for email \'coheredit@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:21','2026-07-12 04:33:21'),
('LOG_6a538992153ed4.84507729',0,'failed_login','Failed login attempt for email \'coheredit@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:22','2026-07-12 04:33:22'),
('LOG_6a53899314a6c5.12498316',0,'failed_login','Failed login attempt for email \'coheredit@gmail.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:23','2026-07-12 04:33:23'),
('LOG_6a53899b2a6ed3.24852328',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:31','2026-07-12 04:33:31'),
('LOG_6a5389a29da634.53210277',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:23:18',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 04:33:38','2026-07-12 04:33:38'),
('LOG_6a5389b467ce33.28832720',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 04:33:56','2026-07-12 04:33:56'),
('LOG_6a538a37a599c7.44036115',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 04:36:07','2026-07-12 04:36:07'),
('LOG_6a538a389efb78.22283280',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-12 04:36:08','2026-07-12 04:36:08'),
('LOG_6a538ac5d21491.01584658',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-12 04:38:29','2026-07-12 04:38:29'),
('LOG_6a538bc0aea1b6.82337912',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-12 04:42:40','2026-07-12 04:42:40'),
('LOG_6a538ebd475803.98506514',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-12 04:55:25','2026-07-12 04:55:25'),
('LOG_6a539952399225.65075371',25,'logout','Admin \'John Doe\' logged out. Session duration: 01:04:26',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 05:40:34','2026-07-12 05:40:34'),
('LOG_6a53996b34ddd0.61444586',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 05:40:59','2026-07-12 05:40:59'),
('LOG_6a5399723cb870.12356241',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:00:07',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 05:41:06','2026-07-12 05:41:06'),
('LOG_6a5399b65f4548.14662388',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 05:42:14','2026-07-12 05:42:14'),
('LOG_6a539a26743276.45567003',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:01:52',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 05:44:06','2026-07-12 05:44:06'),
('LOG_6a539b1f4ec241.34700080',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 05:48:15','2026-07-12 05:48:15'),
('LOG_6a539dc22c06e9.79373300',0,'failed_login','Failed login attempt for email \'g@g.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 05:59:30','2026-07-12 05:59:30'),
('LOG_6a539dda672616.40476746',0,'failed_login','Failed login attempt for email \'g@g.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 05:59:54','2026-07-12 05:59:54'),
('LOG_6a539de20275d6.47545164',0,'failed_login','Failed login attempt for email \'g@g.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 06:00:02','2026-07-12 06:00:02'),
('LOG_6a539de92d7fd5.50434598',0,'failed_login','Failed login attempt for email \'g@g.com\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 06:00:09','2026-07-12 06:00:09'),
('LOG_6a539e02b571f9.31442856',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-12 06:00:34','2026-07-12 06:00:34'),
('LOG_6a539f45f33285.74310772',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:05:57','2026-07-12 06:05:57'),
('LOG_6a539f7a2eb964.46291179',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:00:52',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:06:50','2026-07-12 06:06:50'),
('LOG_6a539faed90567.46965348',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:07:42','2026-07-12 06:07:42'),
('LOG_6a53a131aac714.66889804',25,'logout','Admin \'John Doe\' logged out. Session duration: 00:06:26',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:14:09','2026-07-12 06:14:09'),
('LOG_6a53a135a08e21.02880842',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:14:13','2026-07-12 06:14:13'),
('LOG_6a53a2c2bdd788.22115957',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 127.0.0.1',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:20:50','2026-07-12 06:20:50'),
('LOG_6a53a2c8e293c1.53420981',25,'login','Admin \'John Doe\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 06:20:56','2026-07-12 06:20:56'),
('LOG_6a53a7a34c98b0.41953289',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-12 06:41:39','2026-07-12 06:41:39'),
('LOG_6a53a7ae211279.77450151',25,'Profile Change','Name: \"John Doe\" → \"John Deniel\"',NULL,NULL,NULL,NULL,'2026-07-12 06:41:50','2026-07-12 06:41:50'),
('LOG_6a53a7b8243619.12388986',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-12 06:42:00','2026-07-12 06:42:00'),
('LOG_6a53a7c0841a89.13366956',25,'Security','Password reset code sent to admin email',NULL,NULL,NULL,NULL,'2026-07-12 06:42:08','2026-07-12 06:42:08'),
('LOG_6a53b12c8a5f98.89143907',25,'logout','Admin \'John Deniel\' logged out. Session duration: 01:01:23',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:22:20','2026-07-12 07:22:20'),
('LOG_6a53b13119b157.58137679',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:22:25','2026-07-12 07:22:25'),
('LOG_6a53b2d4020222.06583629',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:06:58',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:29:24','2026-07-12 07:29:24'),
('LOG_6a53b4479da9d5.02909406',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:35:35','2026-07-12 07:35:35'),
('LOG_6a53b572614857.73592651',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:04:58',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:40:34','2026-07-12 07:40:34'),
('LOG_6a53b5862c92d6.52533122',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:40:54','2026-07-12 07:40:54'),
('LOG_6a53b5d58c2689.32281720',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:01:19',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 07:42:13','2026-07-12 07:42:13'),
('LOG_6a54f2f6b3f165.83455283',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 06:15:18','2026-07-13 06:15:18'),
('LOG_6a54fa056fadc5.37313112',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:30:06',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 06:45:25','2026-07-13 06:45:25'),
('LOG_6a550148244674.97490049',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 07:16:24','2026-07-13 07:16:24'),
('LOG_6a550b4b5e8d18.85301324',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:42:43',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 07:59:07','2026-07-13 07:59:07'),
('LOG_6a550c1f658151.45642755',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 08:02:39','2026-07-13 08:02:39'),
('LOG_6a550c90d5a344.88182582',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-13 08:04:32','2026-07-13 08:04:32'),
('LOG_6a550c9474cbf6.87924334',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-13 08:04:36','2026-07-13 08:04:36'),
('LOG_6a550c96e11325.21237185',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-13 08:04:38','2026-07-13 08:04:38'),
('LOG_6a550da0675d63.05093302',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:06:25',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 08:09:04','2026-07-13 08:09:04'),
('LOG_6a550db4a10c69.19599264',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 08:09:24','2026-07-13 08:09:24'),
('LOG_6a550e4ebec5c4.59353973',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-13 08:11:58','2026-07-13 08:11:58'),
('LOG_6a55152be324f6.97260146',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:31:51',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 08:41:15','2026-07-13 08:41:15'),
('LOG_6a551581445d82.64556025',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.128.0 Chrome/148.0.7778.271 Electron/42.5.0 Safari/537.36','2026-07-13 08:42:41','2026-07-13 08:42:41'),
('LOG_6a5516fc93c0d6.41323814',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 08:49:00','2026-07-13 08:49:00'),
('LOG_6a551addf1e359.94478975',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:16:33',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:05:33','2026-07-13 09:05:33'),
('LOG_6a551b1e69de01.57339621',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:06:38','2026-07-13 09:06:38'),
('LOG_6a551c58ef2f52.99137465',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:05:14',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:11:52','2026-07-13 09:11:52'),
('LOG_6a551c7b162b80.99195152',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:12:27','2026-07-13 09:12:27'),
('LOG_6a55218e00b4c3.04329292',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:21:38',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:34:06','2026-07-13 09:34:06'),
('LOG_6a55273db1fc14.99741674',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:58:21','2026-07-13 09:58:21'),
('LOG_6a55275a4ad990.34242778',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:28',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 09:58:50','2026-07-13 09:58:50'),
('LOG_6a552f8ec21052.08557111',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 10:33:50','2026-07-13 10:33:50'),
('LOG_6a566454e2ca64.67321445',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:31:16','2026-07-14 08:31:16'),
('LOG_6a56650f678fa6.35073999',25,'Cancellation Approved','Admin John Deniel approved cancellation request #2 for reservation #17',83,17,NULL,NULL,'2026-07-14 08:34:23','2026-07-14 08:34:23'),
('LOG_6a56651eadbd43.78641235',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:03:21',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:34:38','2026-07-14 08:34:38'),
('LOG_6a56655e362a61.97966537',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:35:42','2026-07-14 08:35:42'),
('LOG_6a56658f892175.98618142',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:49',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:36:31','2026-07-14 08:36:31'),
('LOG_6a5665b63e2947.85274692',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:37:10','2026-07-14 08:37:10'),
('LOG_6a5665d714a863.38591114',25,'Cancellation Approved','Admin John Deniel approved cancellation request #3 for reservation #19',111,19,NULL,NULL,'2026-07-14 08:37:43','2026-07-14 08:37:43'),
('LOG_6a5665f1a0f3b4.17228811',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:59',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:38:09','2026-07-14 08:38:09'),
('LOG_6a5665f4798591.70267854',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:38:12','2026-07-14 08:38:12'),
('LOG_6a5667099d7a78.65445824',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:04:37',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:42:49','2026-07-14 08:42:49'),
('LOG_6a56670fbfdf10.17680654',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 08:42:55','2026-07-14 08:42:55'),
('LOG_6a5669c427ee57.09026706',25,'Cancellation Approved','Admin John Deniel approved cancellation request #6 for reservation #22',104,22,NULL,NULL,'2026-07-14 08:54:28','2026-07-14 08:54:28'),
('LOG_6a5670708de1f6.38246801',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 09:22:56','2026-07-14 09:22:56'),
('LOG_6a5675fb368179.44819365',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:23:38',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 09:46:35','2026-07-14 09:46:35'),
('LOG_6a567f489cf6a7.48052258',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 18:26:16','2026-07-14 18:26:16'),
('LOG_6a567f690462e0.62559404',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:32',NULL,NULL,'152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 18:26:49','2026-07-14 18:26:49'),
('LOG_6a567fffb5ada3.39191177',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 18:29:19','2026-07-14 18:29:19'),
('LOG_6a5687a87aa800.02747686',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 19:02:00','2026-07-14 19:02:00'),
('LOG_6a5687c2819555.41382447',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:26',NULL,NULL,'152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 19:02:26','2026-07-14 19:02:26'),
('LOG_6a5870b9be0131.42643150',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 152.233.68.97',NULL,NULL,'152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 05:48:41','2026-07-16 05:48:41'),
('LOG_6a5870c215d674.36904981',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 05:48:50','2026-07-16 05:48:50'),
('LOG_6a58acc5f33852.92787771',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 10:04:53','2026-07-16 10:04:53'),
('LOG_6a58ad0b8aa523.96391266',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-16 10:06:03','2026-07-16 10:06:03'),
('LOG_6a58af1d088b37.58452303',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.97','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-16 10:14:53','2026-07-16 10:14:53'),
('LOG_6a58eb1de769c6.32332998',25,'logout','Admin \'John Deniel\' logged out. Session duration: 04:25:59',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:30:53','2026-07-16 14:30:53'),
('LOG_6a58eb4179e655.65655955',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:31:29','2026-07-16 14:31:29'),
('LOG_6a58eb5eed4188.04356371',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:29',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:31:58','2026-07-16 14:31:58'),
('LOG_6a58eb6c64fa90.36527044',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:32:12','2026-07-16 14:32:12'),
('LOG_6a58ebd5797989.66790844',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:01:45',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:33:57','2026-07-16 14:33:57'),
('LOG_6a58ebdb8fbbd2.19473324',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:34:03','2026-07-16 14:34:03'),
('LOG_6a58ecb81e8380.65541710',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.121','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:37:44','2026-07-16 14:37:44'),
('LOG_6a5f5ea07f3892.62392588',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-21 11:57:20','2026-07-21 11:57:20'),
('LOG_6a5f5ea73d5bc1.96434390',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-21 11:57:27','2026-07-21 11:57:27'),
('LOG_6a5f5ea9c06a36.47669535',25,'Security','Password reset code sent to admin email',NULL,NULL,NULL,NULL,'2026-07-21 11:57:29','2026-07-21 11:57:29'),
('LOG_6a5f9acc63d5e5.95006163',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 16:14:04','2026-07-21 16:14:04'),
('LOG_6a5f9cb2bb4959.27658481',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:08:06',NULL,NULL,'152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 16:22:10','2026-07-21 16:22:10'),
('LOG_6a5f9cd31da5e3.73906529',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.15.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 16:22:43','2026-07-21 16:22:43'),
('LOG_6a5f9e580fa9a9.75705999',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-21 16:29:12','2026-07-21 16:29:12'),
('LOG_6a5f9f43a78136.36530798',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-21 16:33:07','2026-07-21 16:33:07'),
('LOG_6a5f9f506b4283.52051338',25,'Security','Password reset code sent to admin email',NULL,NULL,NULL,NULL,'2026-07-21 16:33:20','2026-07-21 16:33:20'),
('LOG_6a5fc7ff979718.25134245',0,'failed_login','Failed login attempt for email \'cutehub0@gmail.com\' from IP 152.233.68.98',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 19:26:55','2026-07-21 19:26:55'),
('LOG_6a5fc81291b6c5.96795178',0,'failed_login','Failed login attempt for email \'cutehub0@gmail.com\' from IP 152.233.68.98',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 19:27:14','2026-07-21 19:27:14'),
('LOG_6a5fc81cdf3d98.39320311',0,'failed_login','Failed login attempt for email \'cutehub0@gmail.com\' from IP 152.233.68.98',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 19:27:24','2026-07-21 19:27:24'),
('LOG_6a5ff46acdb309.74067247',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:36:26','2026-07-21 22:36:26'),
('LOG_6a5ff488f24128.19072089',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:36:56','2026-07-21 22:36:56'),
('LOG_6a5ff4b51d9933.54436136',25,'logout','Admin \'John Deniel\' logged out. Session duration: 00:00:44',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:37:41','2026-07-21 22:37:41'),
('LOG_6a5ff4c5bf80b8.36626793',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 152.233.68.98',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:37:57','2026-07-21 22:37:57'),
('LOG_6a5ff4cc6b2c35.69214637',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 152.233.68.98',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:38:04','2026-07-21 22:38:04'),
('LOG_6a5ff4cf839fc0.64075028',0,'failed_login','Failed login attempt for email \'it@villasalud.test\' from IP 152.233.68.98',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:38:07','2026-07-21 22:38:07'),
('LOG_6a5ff4fab51e65.38270302',25,'login','Admin \'John Deniel\' logged in successfully',NULL,NULL,'152.233.68.98','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36','2026-07-21 22:38:50','2026-07-21 22:38:50'),
('LOG_6a5ff50938e877.05797237',25,'System Action','Started editing admin profile information',NULL,NULL,NULL,NULL,'2026-07-21 22:39:05','2026-07-21 22:39:05'),
('LOG_6a5ff50e65c603.81382817',25,'System Action','Cancelled profile editing without saving',NULL,NULL,NULL,NULL,'2026-07-21 22:39:10','2026-07-21 22:39:10'),
('LOG_6a5ff50eaf7097.71847603',25,'Security','Opened password change form',NULL,NULL,NULL,NULL,'2026-07-21 22:39:10','2026-07-21 22:39:10');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `profile_picture` varchar(255) NOT NULL DEFAULT 'default.png',
  `password_reset_code` varchar(6) DEFAULT NULL,
  `password_reset_code_expires_at` timestamp NULL DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'admin',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES
(3,'test@gmail.com','A','A','$2y$12$epBAJuLsb80hLKKVbAL6suVtWRsIOSaRdvwPjT/iRcWXHsiMBGnr2','1234','2025-03-13 13:05:14','2026-07-10 12:37:54','default.png',NULL,NULL,'admin',NULL),
(4,'test1@gmail.com','B','B','$2y$12$XiLT2qurcoCDwjWX1IBHn.FpeQBtSWL79rNyL942q6E45vAXAhYuW','5678','2025-03-13 13:15:44','2026-07-10 12:41:12','default.png',NULL,NULL,'admin',NULL),
(6,'try1@gmail.com','C','C','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','222222222222','2025-03-14 10:34:22','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(7,'try2@gmail.com','D','D','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','123','2025-03-14 10:46:07','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(8,'testing@gmail.com','E','E','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','12345678910','2025-03-14 10:51:31','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(9,'beta@gmail.com','Beta','beta','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','77777777777','2025-03-14 11:19:56','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(10,'pretzel@gmail.com','TesterAlpha','TesterAlpha','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09488642607','2025-03-20 09:21:02','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(14,'jdoe@gmail.com','John','Doe','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','0948-864-2607','2025-05-25 10:34:02','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(15,'freetzel@gmail.com','Marc','Gonzales','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09488642607','2025-05-26 01:53:38','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(16,'mouse@gmail.com','TV','Five','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09465723981','2025-05-30 04:47:39','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(17,'palipate@gmail.com','Pal','Pitate','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09123456789','2025-06-08 04:14:28','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(18,'coheredit@gmail.com','Admin','Admin','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09488642607','2025-06-12 11:01:18','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(19,'iwantcakex@gmail.com','Marc','AdminGasta','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09488642607','2025-06-18 19:10:40','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(20,'marstonjack@gmail.com','Jack','Marston','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','01234567890','2025-06-18 22:15:17','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(21,'daphne@gmail.com','Daph','Ney','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','01234567890','2025-06-19 00:38:33','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(22,'haynako@gmail.com','Juan','Tamad','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09123456789','2026-07-01 19:02:37','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(23,'admin123@gmail.com','John','Deniel','$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','09123456789','2026-07-02 10:46:02','2026-07-10 10:24:33','default.png',NULL,NULL,'admin',NULL),
(25,'it@villasalud.test','John','Deniel','$2y$12$2vUDICaCw4KruUQLnt46gun.BIjxHlLvd0yCdmVrW4Bo89rU.jfK2','09123456789','2026-07-02 20:12:31','2026-07-21 16:33:18','default.png','688788','2026-07-21 16:43:18','super_admin',NULL);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `admin_page_permissions`
--

DROP TABLE IF EXISTS `admin_page_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_page_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `page_slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_page_permissions_admin_id_page_slug_unique` (`admin_id`,`page_slug`),
  KEY `admin_page_permissions_admin_id_index` (`admin_id`),
  CONSTRAINT `admin_page_permissions_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_page_permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `admin_page_permissions` WRITE;
/*!40000 ALTER TABLE `admin_page_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_page_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `availabilities`
--

DROP TABLE IF EXISTS `availabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `availabilities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` enum('Available','Half','Nearly','Full','Closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Available',
  `is_override` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `availabilities`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `availabilities` WRITE;
/*!40000 ALTER TABLE `availabilities` DISABLE KEYS */;
INSERT INTO `availabilities` VALUES
(1,'2025-06-06','Available',0,'2025-06-09 01:42:03','2025-06-09 01:42:03'),
(2,'2025-06-01','Available',0,'2025-06-09 01:42:40','2025-06-09 01:42:40'),
(3,'2025-06-04','Available',0,'2025-06-09 01:43:15','2025-06-09 01:43:15'),
(4,'2025-06-02','Available',0,'2025-06-09 02:12:16','2025-06-09 02:12:16'),
(5,'2025-06-05','Available',0,'2025-06-09 02:13:54','2025-06-09 02:13:54'),
(6,'2025-06-12','Available',0,'2025-06-09 02:13:58','2025-06-09 02:18:50'),
(7,'2025-06-18','Full',0,'2025-06-09 02:14:01','2025-06-17 02:41:39'),
(8,'2025-06-19','Available',0,'2025-06-09 02:14:04','2025-06-09 02:14:04'),
(9,'2025-06-10','Half',0,'2025-06-09 02:16:44','2025-06-11 03:45:05'),
(10,'2025-06-09','Available',0,'2025-06-09 02:18:40','2025-06-09 02:18:40'),
(11,'2025-06-13','Available',0,'2025-06-09 02:19:03','2025-06-09 02:19:03'),
(12,'2025-06-30','Available',0,'2025-06-09 05:09:57','2025-06-09 05:09:57'),
(13,'2025-06-28','Nearly',0,'2025-06-09 05:10:01','2025-06-09 05:10:01'),
(14,'2025-06-22','Full',0,'2025-06-11 05:42:32','2025-06-11 05:42:32'),
(15,'2025-06-17','Full',0,'2025-06-17 03:10:42','2025-06-17 03:10:42'),
(16,'2025-06-15','Available',0,'2025-06-25 03:01:05','2025-06-25 03:01:05'),
(17,'2026-07-27','Closed',0,'2026-07-02 22:33:33','2026-07-02 22:33:33'),
(18,'2026-07-14','Half',0,'2026-07-02 22:35:52','2026-07-02 22:35:52'),
(19,'2026-07-23','Nearly',0,'2026-07-02 22:35:59','2026-07-02 22:35:59'),
(20,'2026-07-31','Full',0,'2026-07-02 22:36:41','2026-07-02 22:36:41'),
(21,'2026-07-08','Full',0,'2026-07-12 05:42:44','2026-07-12 05:42:44'),
(22,'2026-07-09','Closed',0,'2026-07-12 05:42:48','2026-07-12 05:42:48'),
(23,'2026-08-04','Full',0,'2026-07-12 06:22:14','2026-07-12 06:22:14'),
(24,'2026-08-06','Closed',0,'2026-07-12 06:28:17','2026-07-12 06:28:23');
/*!40000 ALTER TABLE `availabilities` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cancellation_requests`
--

DROP TABLE IF EXISTS `cancellation_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cancellation_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reserve_id` int NOT NULL,
  `patron_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','approved','denied') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_id` int DEFAULT NULL,
  `admin_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cancellation_requests_reserve_id_foreign` (`reserve_id`),
  KEY `cancellation_requests_admin_id_foreign` (`admin_id`),
  CONSTRAINT `cancellation_requests_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON DELETE SET NULL,
  CONSTRAINT `cancellation_requests_reserve_id_foreign` FOREIGN KEY (`reserve_id`) REFERENCES `reservation` (`reserve_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancellation_requests`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cancellation_requests` WRITE;
/*!40000 ALTER TABLE `cancellation_requests` DISABLE KEYS */;
INSERT INTO `cancellation_requests` VALUES
(1,9,'mricalde@gmail.com','Testing the cancellation feature - need to cancel this reservation.','approved',25,'Cancellation approved as requested. Your reservation has been cancelled.','2026-07-04 06:29:57','2026-07-04 06:31:36'),
(2,17,'Johndenielescuro@gmail.com','Date is moved','approved',25,'Thank you!','2026-07-14 08:31:00','2026-07-14 08:34:23'),
(3,19,'Johndenielescuro@gmail.com',NULL,'approved',25,'We understand.','2026-07-14 08:37:03','2026-07-14 08:37:43'),
(4,20,'admin-test@example.com',NULL,'approved',25,NULL,'2026-07-14 08:44:00','2026-07-14 08:44:10'),
(5,21,'patron-test@example.com',NULL,'approved',25,'a','2026-07-14 08:50:46','2026-07-14 08:50:54'),
(6,22,'ad@gmail.com',NULL,'approved',25,'ahaha','2026-07-14 08:54:21','2026-07-14 08:54:28');
/*!40000 ALTER TABLE `cancellation_requests` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES
(4,'John','johnny@gmail.com','Everything was so good and perfect!','2026-07-12 07:30:08','2026-07-12 07:30:08');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_fields`
--

DROP TABLE IF EXISTS `form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_fields` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `form_id` bigint unsigned NOT NULL,
  `field_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `placeholder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `order` int NOT NULL DEFAULT '0',
  `options` json DEFAULT NULL,
  `validation_rules` json DEFAULT NULL,
  `has_other_option` tinyint(1) NOT NULL DEFAULT '0',
  `is_fixed` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_fields_form_id_foreign` (`form_id`),
  CONSTRAINT `form_fields_form_id_foreign` FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_fields`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_fields` WRITE;
/*!40000 ALTER TABLE `form_fields` DISABLE KEYS */;
INSERT INTO `form_fields` VALUES
(1,1,'text','Name','name','Your full name',1,0,NULL,'[\"required\", \"string\", \"max:255\"]',0,1,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(2,1,'email','Email','email','your@email.com',1,1,NULL,'[\"required\", \"email\", \"max:255\"]',0,1,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(3,1,'tel','Contact Number','contact_number','e.g. 09171234567',1,2,NULL,'[\"required\", \"string\", \"max:20\"]',0,1,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(4,1,'date','Date','date',NULL,1,3,NULL,'[\"required\", \"date\"]',0,1,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(5,1,'select','Select Period','period','Choose AM or PM',1,4,'[{\"label\": \"AM\", \"value\": \"AM\"}, {\"label\": \"PM\", \"value\": \"PM\"}]','[\"required\"]',0,1,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(6,1,'select','Time Slot','time','Select a time slot',1,5,'[]','[\"required\"]',0,1,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(7,1,'select','Venue','venue','Choose a venue',1,6,'[{\"label\": \"Villa I\", \"value\": \"Villa I\"}, {\"label\": \"Villa II\", \"value\": \"Villa II\"}, {\"label\": \"Elizabeth Hall\", \"value\": \"Elizabeth Hall\"}, {\"label\": \"Private Pool\", \"value\": \"Private Pool\"}]','[\"required\", \"string\"]',1,0,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(8,1,'select','Event Type','event_type','Choose event type',1,7,'[{\"label\": \"Baptismal Package\", \"value\": \"Baptismal Package\"}, {\"label\": \"Birthday Package\", \"value\": \"Birthday Package\"}, {\"label\": \"Debut Package\", \"value\": \"Debut Package\"}, {\"label\": \"Kiddie Package\", \"value\": \"Kiddie Package\"}, {\"label\": \"Wedding Package\", \"value\": \"Wedding Package\"}, {\"label\": \"Standard Package\", \"value\": \"Standard Package\"}]','[\"required\", \"string\"]',1,0,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(9,1,'select','Theme / Motif','theme_motif','Choose theme/motif',1,8,'[{\"label\": \"Floral\", \"value\": \"Floral\"}, {\"label\": \"Rustic\", \"value\": \"Rustic\"}, {\"label\": \"Elegant\", \"value\": \"Elegant\"}, {\"label\": \"Beach\", \"value\": \"Beach\"}, {\"label\": \"Modern\", \"value\": \"Modern\"}]','[\"required\", \"string\"]',1,0,1,'2026-07-04 03:28:33','2026-07-14 09:24:59'),
(10,1,'textarea','Other Request','message','Please describe your specific requirements...',1,9,NULL,'[\"required\", \"string\"]',0,0,1,'2026-07-04 03:28:33','2026-07-14 09:24:59');
/*!40000 ALTER TABLE `form_fields` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `forms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forms_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
INSERT INTO `forms` VALUES
(1,'Reservation Form','reservation','Main reservation inquiry form for patrons and admin use.',1,1,'2026-07-04 03:28:33','2026-07-14 09:25:07');
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `guest_consents`
--

DROP TABLE IF EXISTS `guest_consents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest_consents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `guest_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consented_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guest_consents_guest_token_unique` (`guest_token`),
  KEY `guest_consents_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_consents`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `guest_consents` WRITE;
/*!40000 ALTER TABLE `guest_consents` DISABLE KEYS */;
INSERT INTO `guest_consents` VALUES
(18,'dOKz20fz0ps5nmqvNgPehdUcioDCqBMYIqGLuEWD',NULL,NULL,'2026-07-02 10:37:21','2026-08-01 10:37:21','136.158.33.196','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 10:37:21','2026-07-02 10:37:21');
/*!40000 ALTER TABLE `guest_consents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inquiry`
--

DROP TABLE IF EXISTS `inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inquiry` (
  `inquiry_id` int NOT NULL AUTO_INCREMENT,
  `created_by_type` enum('admin','patron') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'patron',
  `admin_id` int DEFAULT NULL,
  `time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patron_id` int DEFAULT NULL,
  `tracking_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` date NOT NULL,
  `venue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_motif` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_event_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `other_theme_motif` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `other_venue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `status` enum('Pending','In Progress','Completed','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'Pending',
  `form_data` json DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`inquiry_id`),
  UNIQUE KEY `tracking_code` (`tracking_code`),
  KEY `fk_inquiry_patron` (`patron_id`),
  KEY `idx_inquiry_creator_type` (`created_by_type`),
  KEY `idx_inquiry_admin_id` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inquiry` WRITE;
/*!40000 ALTER TABLE `inquiry` DISABLE KEYS */;
INSERT INTO `inquiry` VALUES
(7,'patron',NULL,'05:06:00',16,NULL,'Kumain kana lab?','2025-03-28 13:01:41','2025-03-21','Villa I',NULL,'Floral',NULL,NULL,NULL,'Completed',NULL,'2025-06-07 16:47:06'),
(14,'patron',NULL,'21:04:00',23,NULL,'sup','2025-03-28 13:12:57','2025-04-05','Villa I',NULL,'Rustic','Graduation','EY',NULL,'Completed',NULL,'2025-06-07 16:47:06'),
(15,'patron',NULL,'21:04:00',24,NULL,'sup','2025-03-28 13:13:05','2025-04-05','Villa I',NULL,'Floral','Graduation','EY',NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(16,'patron',NULL,'21:04:00',25,NULL,'sup','2025-03-28 13:13:08','2025-04-05','Villa I',NULL,'Floral','Graduation','EY',NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(17,'patron',NULL,'21:04:00',26,NULL,'sup','2025-03-28 13:13:39','2025-04-05','Villa I',NULL,'Floral','Graduation','EY',NULL,'Completed',NULL,'2025-06-07 16:47:06'),
(18,'patron',NULL,'23:20:00',32,NULL,'testing 123','2025-03-28 13:22:21','2025-04-10','Villa I','Baptismal Package','Floral','grad','B','House','Completed',NULL,'2025-06-07 16:47:06'),
(19,'patron',NULL,'09:00:00',33,NULL,'mama mo','2025-03-28 21:58:28','2025-03-31','Villa I','Birthday Package','Beach',NULL,NULL,'bahay ','Pending',NULL,'2025-06-07 16:47:06'),
(20,'patron',NULL,'09:00:00',34,NULL,'mama mo','2025-03-28 21:59:35','2025-03-31','Villa I','Birthday Package','Beach',NULL,NULL,'bahay ','Completed',NULL,'2025-06-07 16:47:06'),
(21,'patron',NULL,'00:39:00',35,NULL,'hi','2025-04-05 04:38:24','2025-04-11','Villa II','Birthday Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(22,'patron',NULL,'13:50:00',36,NULL,'hhaha','2025-04-05 04:49:29','2025-04-06','Private Pool','Standard Package','Modern',NULL,NULL,NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(24,'patron',NULL,'07:12:00',38,NULL,'want to inquiry','2025-04-05 10:15:15','2025-04-15','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Completed',NULL,'2025-06-07 16:47:06'),
(25,'patron',NULL,'10:30:00',39,NULL,'Minimalistic ','2025-04-07 16:21:37','2025-04-16','Villa I','Kiddie Package','Modern',NULL,NULL,'House','In Progress',NULL,'2025-06-07 16:47:06'),
(26,'patron',NULL,'10:30:00',40,NULL,'Minimalistic ','2025-04-07 16:24:42','2025-04-16','Villa I','Kiddie Package','Modern',NULL,NULL,'House','In Progress',NULL,'2025-06-07 16:47:06'),
(27,'patron',NULL,'19:35:00',41,NULL,'minimal','2025-04-25 18:33:30','2025-04-24','Elizabeth Hall','Birthday Package','Modern',NULL,NULL,NULL,'In Progress',NULL,'2025-06-07 16:47:06'),
(28,'patron',NULL,'11:04:00',42,NULL,'wala naman na','2025-05-26 15:20:28','2025-05-06','Villa II','Birthday Package','Elegant',NULL,NULL,NULL,'Cancelled',NULL,'2025-06-07 16:47:06'),
(29,'patron',NULL,'23:25:00',43,NULL,'none','2025-05-26 15:22:03','2031-11-28','Elizabeth Hall','Baptismal Package','Rustic','grad',NULL,NULL,'In Progress',NULL,'2025-06-07 16:47:06'),
(30,'admin',NULL,'00:32:00',45,NULL,'lobo','2025-05-26 15:37:14','2025-05-01','Private Pool','Standard Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(31,'patron',NULL,'12:00:00',46,NULL,'madaming pera na ibibigay sa kaniya tapos hati kame','2025-05-26 15:38:49','2025-08-05','Private Pool','Birthday Package','Elegant',NULL,NULL,NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(32,'admin',NULL,'08:28:00',47,NULL,'Wala naman','2025-06-05 15:22:51','2025-06-26','Elizabeth Hall','Debut Package','Rustic',NULL,NULL,NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(33,'admin',NULL,'17:49:00',48,NULL,'all goods','2025-06-05 15:43:27','2025-06-24','Elizabeth Hall','Kiddie Package','Elegant',NULL,NULL,NULL,'Pending',NULL,'2025-06-07 16:47:06'),
(34,'patron',NULL,'10:00:00',56,NULL,'Test','2025-06-07 12:05:56','2025-06-17','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'In Progress',NULL,'2025-06-09 00:32:14'),
(35,'patron',NULL,'10:10:00',57,NULL,'Test','2025-06-07 12:07:01','2025-06-19','Villa II','Baptismal Package','Rustic',NULL,NULL,NULL,'In Progress',NULL,'2025-06-09 00:31:39'),
(36,'patron',NULL,'9am–11am',NULL,'VS-224D44','Test','2025-06-09 08:43:30','2025-06-20','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2025-06-09 08:43:30'),
(37,'patron',NULL,'10am–12pm',60,'VS-8C063B','Test','2025-06-09 10:30:16','2025-06-28','Villa II','Debut Package','Rustic',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:01:51'),
(38,'patron',NULL,'2pm–4pm',61,'VS-BD70A0','Test','2025-06-10 10:49:15','2025-06-19','Elizabeth Hall','Debut Package','Floral',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:02:22'),
(39,'patron',NULL,'10am–12pm',62,'VS-E4BA3F','test','2025-06-10 11:04:14','2025-06-27','Private Pool','Baptismal Package','Rustic',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:02:54'),
(40,'patron',NULL,'2pm–4pm',62,'VS-619B6F','testing testing','2025-06-10 11:05:26','2025-06-13','Private Pool','Birthday Package','Beach',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:06:01'),
(41,'patron',NULL,'9am–11am',62,'VS-21B1A5','testing testing 1','2025-06-10 11:12:50','2025-06-25','Villa I','Baptismal Package','Elegant',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:12:53'),
(42,'patron',NULL,'2pm–4pm',62,'VS-101093','testing testing 2','2025-06-10 11:32:49','2025-06-13','Villa I','Birthday Package','Rustic',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:15:18'),
(43,'patron',NULL,'9am–11am',62,'VS-60ED93','testing testing 3','2025-06-10 11:40:22','2025-06-14','Elizabeth Hall','Wedding Package','Rustic',NULL,NULL,NULL,'Completed',NULL,'2025-06-12 14:17:40'),
(44,'patron',NULL,'9am–11am',NULL,'VS-B1B3CA','testing testing 4','2025-06-10 11:59:55','2025-07-12','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2025-06-10 11:59:55'),
(45,'patron',14,'4pm–6pm',NULL,'VS-23572B','testing testing 5','2025-06-10 12:02:10','2025-06-26','Private Pool','Birthday Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2025-06-10 12:02:10'),
(46,'admin',14,'9am–11am',NULL,'VS-03CA64','testing testing 6','2025-06-10 12:06:56','2025-06-20','Private Pool','Birthday Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2025-06-10 12:06:56'),
(47,'admin',14,'2pm–4pm',NULL,'VS-E57444','testing 7','2025-06-11 01:52:30','2025-06-13','Others','Others','Others','test','test','test','Pending',NULL,'2025-06-11 01:52:30'),
(48,'patron',NULL,'2pm–4pm',66,'VS-714101','testting 8','2025-06-11 05:07:19','2025-06-20','Others','Others','Others','test','test','test','Completed',NULL,'2025-06-12 14:22:41'),
(49,'patron',NULL,'2pm–4pm',67,'VS-D9EFA5','testing 8','2025-06-11 05:09:33','2025-06-12','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'In Progress',NULL,'2025-06-11 08:05:20'),
(50,'patron',NULL,'9am–11am',68,'VS-93FEEB','testing','2025-06-11 05:26:49','2025-06-27','Others','Others','Others','test','test','testting','Completed',NULL,'2025-06-11 08:04:25'),
(51,'patron',NULL,'9am–11am',69,'VS-6E534D','Taru tatu taru','2025-06-11 22:52:38','2025-06-25','Villa I','Baptismal Package','Elegant',NULL,NULL,NULL,'Cancelled',NULL,'2026-07-04 06:31:36'),
(52,'admin',18,'3pm–5pm',NULL,'VS-1A9FE5','none','2025-06-12 11:34:09','2025-06-20','Private Pool','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending',NULL,'2025-06-12 11:34:09'),
(53,'admin',18,'2pm–4pm',71,'VS-3D8764','None 4','2025-06-12 11:58:11','2025-06-18','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2025-06-12 11:58:11'),
(54,'admin',18,'9am–11am',72,'VS-C17EB4','None 5','2025-06-12 11:59:56','2025-06-23','Villa II','Birthday Package','Rustic',NULL,NULL,NULL,'Pending',NULL,'2025-06-12 11:59:56'),
(55,'patron',NULL,'9am–11am',73,'VS-44A5A2','sample other request','2025-06-16 21:26:12','2025-06-21','Villa II','Wedding Package','Elegant',NULL,NULL,NULL,'In Progress',NULL,'2025-06-16 21:27:31'),
(56,'patron',NULL,'9am–1pm',73,'VS-39B7FF','Sample Other Request','2025-06-17 00:19:47','2025-06-17','Elizabeth Hall','Wedding Package','Elegant',NULL,NULL,NULL,'Pending',NULL,'2025-06-17 00:19:47'),
(57,'patron',NULL,'11am–3pm',73,'VS-0D3ECA','Other dsadsa','2025-06-17 00:43:12','2025-06-13','Private Pool','Kiddie Package','Elegant',NULL,NULL,NULL,'Pending',NULL,'2025-06-17 00:43:12'),
(58,'patron',NULL,'4pm-8pm',73,'VS-C47F2D','dsadsas','2025-06-17 00:43:56','2025-06-30','Villa II','Standard Package','Rustic',NULL,NULL,NULL,'Pending',NULL,'2025-06-17 00:43:56'),
(59,'patron',NULL,'9am–1pm',74,'VS-6A71A7','May I request for additional 10 (ten) tables. Thank you!','2025-06-17 01:47:34','2025-06-17','Elizabeth Hall','Wedding Package','Elegant',NULL,NULL,NULL,'In Progress',NULL,'2025-06-17 01:50:54'),
(60,'patron',NULL,'4pm–6pm',73,'VS-3A5970','Sample Outpt','2025-06-17 03:27:15','2025-06-17','Private Pool','Kiddie Package','Elegant',NULL,NULL,NULL,'Pending',NULL,'2025-06-17 03:27:15'),
(61,'patron',NULL,'10am–2pm',73,'VS-1C903A','Request for additional 10 tables and chairs. Thank you!','2025-06-17 03:40:49','2025-06-30','Private Pool','Kiddie Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2025-06-17 03:40:49'),
(62,'patron',NULL,'5pm–9pm',73,'VS-46C562','Request for additional 10 (ten) tables and chairs. Thank you!','2025-06-17 03:45:24','2025-06-30','Private Pool','Birthday Package','Beach',NULL,NULL,NULL,'In Progress',NULL,'2025-06-17 03:54:59'),
(63,'patron',NULL,'5pm–9pm',74,'VS-EC0163','Request for RGB light and additional ten (10) tables and 5 chairs each. Thank you!','2025-06-17 04:29:18','2025-06-28','Elizabeth Hall','Debut Package','Modern',NULL,NULL,NULL,'Completed',NULL,'2025-06-17 04:31:33'),
(64,'patron',NULL,'10am–2pm',75,'VS-DBD37B','Request for additional ten (10) tables and five (5) chairs for each table. Thank you!','2025-06-18 04:53:01','2025-06-30','Elizabeth Hall','Kiddie Package','Elegant',NULL,NULL,NULL,'Pending',NULL,'2025-06-18 04:53:01'),
(65,'patron',NULL,'10am–2pm',73,'VS-621573','testing request','2025-06-18 04:55:50','2025-06-28','Private Pool','Wedding Package','Rustic',NULL,NULL,NULL,'Pending',NULL,'2025-06-18 04:55:50'),
(66,'patron',NULL,'10am–2pm',75,'VS-9198D8','Request for additional ten (10) tables and five (5) chairs for each table. Thank you!','2025-06-18 04:57:29','2025-06-28','Elizabeth Hall','Standard Package','Beach',NULL,NULL,NULL,'In Progress',NULL,'2025-06-18 05:00:23'),
(67,'patron',NULL,'9am–1pm',73,'VS-84AD78','Request for additional ten (10) tables and five (5) chairs for each table. Thank you!','2025-06-18 05:02:00','2025-06-27','Elizabeth Hall','Wedding Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2025-06-18 05:02:00'),
(68,'patron',NULL,'10am–2pm',74,'VS-F184F7','Request for additional ten (10) tables and five (5) chairs for each table. Thank you!','2025-06-18 05:04:15','2025-06-27','Private Pool','Birthday Package','Elegant',NULL,NULL,NULL,'In Progress',NULL,'2025-06-18 05:04:32'),
(69,'patron',NULL,'2pm–4pm',76,'VS-994D73','Nothing special','2025-06-18 19:19:05','2025-06-25','Private Pool','Standard Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2025-06-18 19:19:05'),
(70,'patron',NULL,'9am–11am',77,'VS-484814','More drinks and chairs','2025-06-18 19:20:52','2025-09-09','Others','Others','Others','Graduation','Party','Tagaytay','Completed',NULL,'2025-06-18 19:21:53'),
(71,'patron',NULL,'9am–1pm',78,'VS-44A1F6','None','2025-06-18 22:17:24','2025-06-26','Villa II','Debut Package','Rustic',NULL,NULL,NULL,'Completed',NULL,'2025-06-18 22:18:28'),
(72,'patron',NULL,'9am–1pm',77,'VS-E14389','non (testing)','2025-06-19 00:40:30','2025-06-29','Villa I','Debut Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2025-06-19 00:40:30'),
(73,'patron',NULL,'9am–1pm',77,'VS-953D75','None','2025-06-19 02:10:17','2025-06-29','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2025-06-19 02:10:17'),
(74,'patron',NULL,'9am–1pm',79,'VS-F23701','asd','2026-07-01 09:05:51','2026-12-12','Villa II','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending',NULL,'2026-07-01 09:05:51'),
(75,'patron',NULL,'9am–1pm',80,'VS-229CF9','ads','2026-07-02 08:52:18','2026-12-12','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2026-07-02 08:52:18'),
(76,'patron',NULL,'9am–1pm',81,'VS-B8F315','asdads','2026-07-02 10:32:27','2026-12-12','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2026-07-02 10:32:27'),
(77,'patron',NULL,'9am–1pm',82,'VS-63EC42','asd','2026-07-02 10:32:54','2026-12-13','Elizabeth Hall','Baptismal Package','Floral',NULL,NULL,NULL,'Pending',NULL,'2026-07-02 10:32:54'),
(78,'patron',NULL,'9am–1pm',79,'VS-5CFF16','1123','2026-07-02 10:36:37','2026-12-14','Villa II','Baptismal Package','Floral',NULL,NULL,NULL,'Completed',NULL,'2026-07-02 20:13:07'),
(79,'patron',NULL,'4pm-8pm',79,'VS-ED5889','ads','2026-07-02 12:19:26','2026-12-15','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Completed',NULL,'2026-07-02 19:55:05'),
(80,'patron',NULL,'10am–12pm',83,'VS-BE3D30','Purple Pleaseeee','2026-07-02 19:23:55','2026-07-05','Villa II','Birthday Package','Others',NULL,'Kuromi',NULL,'Completed',NULL,'2026-07-02 19:51:05'),
(81,'patron',NULL,'5pm–9pm',84,'VS-5EB482','Beach lezgoo','2026-07-02 20:14:13','2026-07-04','Elizabeth Hall','Birthday Package','Beach',NULL,NULL,NULL,'Pending',NULL,'2026-07-02 20:14:13'),
(82,'patron',NULL,'4pm-8pm',79,'VS-D8F68F','Yesisr','2026-07-04 06:13:17','2026-07-05','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-05\", \"name\": \"John Doe\", \"time\": \"4pm-8pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"PM\", \"message\": \"Yesisr\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-04 06:13:17'),
(83,'patron',NULL,'9am–1pm',79,'VS-B4CE47','yes','2026-07-05 04:47:23','2026-07-07','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Cancelled','{\"date\": \"2026-07-07\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"yes\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-14 08:34:23'),
(84,'patron',NULL,'9am–1pm',84,'VS-7C3612','Hello','2026-07-05 05:13:59','2026-12-05','Elizabeth Hall','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-12-05\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"AM\", \"message\": \"Hello\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-05 05:13:59'),
(85,'patron',NULL,'9am–1pm',84,'VS-8E8C53','123','2026-07-05 05:14:32','2026-07-06','Villa I','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-06\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"123\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-05 05:14:32'),
(86,'patron',NULL,'10am–2pm',85,'VS-47A91C','asd','2026-07-05 05:15:16','2026-07-05','Elizabeth Hall','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-05\", \"name\": \"jj\", \"time\": \"10am–2pm\", \"email\": \"123123@adsasd.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"01203132132\"}','2026-07-05 05:15:16'),
(87,'patron',NULL,'5pm–9pm',84,'VS-ED2584','a','2026-07-05 05:15:42','2026-07-05','Villa II','Debut Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-05\", \"name\": \"john\", \"time\": \"5pm–9pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa II\", \"period\": \"PM\", \"message\": \"a\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09766736245\"}','2026-07-05 05:15:42'),
(88,'patron',NULL,'9am–1pm',86,'VS-5BFBCC','asdads','2026-07-08 00:45:09','2026-07-08','Villa II','Birthday Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-08\", \"name\": \"aa\", \"time\": \"9am–1pm\", \"email\": \"johndeniel1818@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"asdads\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-08 00:45:09'),
(89,'patron',NULL,'10am–2pm',86,'VS-299C16','a','2026-07-08 01:02:58','2026-07-08','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-08\", \"name\": \"aha a\", \"time\": \"10am–2pm\", \"email\": \"johndeniel1818@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-08 01:02:58'),
(90,'patron',NULL,'9am–1pm',87,'VS-509061','asd','2026-07-09 15:03:49','2026-07-11','Villa II','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-11\", \"name\": \"asdads\", \"time\": \"9am–1pm\", \"email\": \"asdsda@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-09 15:03:49'),
(91,'patron',NULL,'9am–1pm',79,'VS-96670C','asd','2026-07-09 15:06:49','2026-07-11','Villa II','Birthday Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-11\", \"name\": \"lamine\", \"time\": \"9am–1pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-09 15:06:49'),
(92,'patron',NULL,'9am–1pm',88,'VS-B081EA','ads','2026-07-09 15:07:39','2026-07-24','Elizabeth Hall','Debut Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-24\", \"name\": \"asdsad\", \"time\": \"9am–1pm\", \"email\": \"aksmdamsd@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"AM\", \"message\": \"ads\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456788\"}','2026-07-09 15:07:39'),
(93,'patron',NULL,'9am–1pm',89,'VS-3E602C','asd','2026-07-09 15:09:55','2026-07-30','Villa II','Birthday Package','Elegant',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-30\", \"name\": \"asddas\", \"time\": \"9am–1pm\", \"email\": \"fuckyou@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09123456789\"}','2026-07-09 15:09:55'),
(94,'patron',NULL,'9am–1pm',90,'VS-ABE494','asd','2026-07-09 15:14:34','2026-07-22','Private Pool','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-22\", \"name\": \"asddas\", \"time\": \"9am–1pm\", \"email\": \"123123@adsas.com\", \"venue\": \"Private Pool\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-09 15:14:34'),
(95,'patron',NULL,'9am–1pm',85,'VS-477214','asd','2026-07-09 15:15:48','2026-07-16','Villa I','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-16\", \"name\": \"aads\", \"time\": \"9am–1pm\", \"email\": \"123123@adsasd.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-09 15:15:48'),
(96,'patron',NULL,'9am–1pm',91,'VS-744A5C','asd','2026-07-09 15:19:35','2026-07-30','Villa I','Baptismal Package','Elegant',NULL,NULL,NULL,'Completed','{\"date\": \"2026-07-30\", \"name\": \"asdads\", \"time\": \"9am–1pm\", \"email\": \"ad@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09123456789\"}','2026-07-10 13:24:36'),
(97,'patron',NULL,'9am–11am',84,'VS-E59D9E','N/A','2026-07-12 05:49:02','2026-08-03','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-08-03\", \"name\": \"John\", \"time\": \"9am–11am\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"N/A\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-12 05:49:02'),
(98,'patron',NULL,'9am–1pm',85,'VS-E39441','aaa','2026-07-12 05:50:54','2026-07-10','Villa I','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-10\", \"name\": \"asddas\", \"time\": \"9am–1pm\", \"email\": \"123123@adsasd.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"aaa\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-12 05:50:54'),
(99,'patron',NULL,'11am–3pm',84,'VS-1A9993','asd','2026-07-12 05:55:29','2026-07-01','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-01\", \"name\": \"John deniel\", \"time\": \"11am–3pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-12 05:55:29'),
(100,'patron',NULL,'9am–1pm',92,'VS-68B9B3','Test reservation from automated testing','2026-07-12 05:57:26','2026-07-25','Villa I','Birthday Package','Modern',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-25\", \"name\": \"Test User\", \"time\": \"9am–1pm\", \"email\": \"test@example.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"Test reservation from automated testing\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Modern\", \"contact_number\": \"09171234567\"}','2026-07-12 05:57:26'),
(101,'patron',NULL,'4pm-8pm',93,'VS-ED67FD','Test reservation 2','2026-07-12 05:58:38','2026-08-15','Elizabeth Hall','Wedding Package','Elegant',NULL,NULL,NULL,'Pending','{\"date\": \"2026-08-15\", \"name\": \"Test User 2\", \"time\": \"4pm-8pm\", \"email\": \"test2@example.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"PM\", \"message\": \"Test reservation 2\", \"event_type\": \"Wedding Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09179876543\"}','2026-07-12 05:58:38'),
(102,'patron',NULL,'10am–12pm',94,'VS-111AA7','Admin test reservation','2026-07-12 06:01:05','2026-08-20','Villa I','Birthday Package','Elegant',NULL,NULL,NULL,'Pending','{\"date\": \"2026-08-20\", \"name\": \"Admin Test User\", \"time\": \"10am–12pm\", \"email\": \"admin-test@example.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"Admin test reservation\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09171112222\"}','2026-07-12 06:01:05'),
(103,'patron',NULL,'9am–1pm',84,'VS-7D4190','a','2026-07-12 06:07:19','2026-07-14','Villa I','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-14\", \"name\": \"asdads\", \"time\": \"9am–1pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-12 06:07:19'),
(104,'patron',NULL,'9am–11am',91,'VS-60CA33','ds','2026-07-12 06:08:22','2026-07-15','Villa II','Debut Package','Floral',NULL,NULL,NULL,'Cancelled','{\"date\": \"2026-07-15\", \"name\": \"aads\", \"time\": \"9am–11am\", \"email\": \"ad@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"ds\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 08:54:28'),
(105,'patron',NULL,'9am–1pm',95,'VS-495751','Test patron toast','2026-07-12 06:11:32','2026-08-25','Villa II','Debut Package','Elegant',NULL,NULL,NULL,'Completed','{\"date\": \"2026-08-25\", \"name\": \"Patron Test\", \"time\": \"9am–1pm\", \"email\": \"patron-test@example.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"Test patron toast\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09179998888\"}','2026-07-14 08:50:36'),
(106,'patron',NULL,'10am–12pm',94,'VS-81D29E','Admin test reservation','2026-07-12 06:12:24','2026-09-10','Villa I','Birthday Package','Elegant',NULL,NULL,NULL,'Completed','{\"date\": \"2026-09-10\", \"name\": \"Admin Test User\", \"time\": \"10am–12pm\", \"email\": \"admin-test@example.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"Admin test reservation\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09175556666\"}','2026-07-14 08:43:18'),
(107,'patron',NULL,'9am–11am',84,'VS-3DEA22','aa','2026-07-12 06:14:43','2026-07-14','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-14\", \"name\": \"aads\", \"time\": \"9am–11am\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"aa\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-12 06:14:43'),
(108,'patron',NULL,'11am–1pm',84,'VS-ADFDF5','N/a','2026-07-12 06:21:46','2026-08-04','Villa I','Kiddie Package','Floral',NULL,NULL,NULL,'In Progress','{\"date\": \"2026-08-04\", \"name\": \"John\", \"time\": \"11am–1pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"N/a\", \"event_type\": \"Kiddie Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-12 07:25:53'),
(109,'patron',NULL,'9am–11am',84,'VS-D957F4','N/a','2026-07-12 06:27:57','2026-08-06','Villa I','Kiddie Package','Floral',NULL,NULL,NULL,'Cancelled','{\"date\": \"2026-08-06\", \"name\": \"John\", \"time\": \"9am–11am\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"N/a\", \"event_type\": \"Kiddie Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-12 07:25:47'),
(110,'patron',NULL,'10am–2pm',84,'VS-6D0740','Please be cute!','2026-07-12 07:33:26','2026-08-17','Elizabeth Hall','Kiddie Package','Beach',NULL,NULL,NULL,'Completed','{\"date\": \"2026-08-17\", \"name\": \"John\", \"time\": \"10am–2pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"AM\", \"message\": \"Please be cute!\", \"event_type\": \"Kiddie Package\", \"theme_motif\": \"Beach\", \"contact_number\": \"09766736245\"}','2026-07-14 08:43:07'),
(111,'patron',NULL,'9am–1pm',79,'VS-5082DB','Yes','2026-07-14 08:35:33','2026-07-16','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Cancelled','{\"date\": \"2026-07-16\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"Yes\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 08:37:43'),
(112,'patron',NULL,'9am–1pm',79,'VS-9AB2A1','aa','2026-07-14 18:24:25','2026-07-28','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-28\", \"name\": \"johnny\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"aa\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-14 18:24:25'),
(113,'patron',NULL,'9am–1pm',79,'VS-1EB243','a','2026-07-14 18:27:29','2026-07-29','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-29\", \"name\": \"nukoww\", \"time\": \"9am–1pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 18:27:29'),
(114,'patron',NULL,'9am–1pm',79,'VS-B50050','a','2026-07-14 19:01:15','2026-07-27','Villa I','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-27\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 19:01:15'),
(115,'patron',NULL,'4pm-8pm',79,'VS-CEF1F2','a','2026-07-14 19:02:52','2026-07-26','Villa I','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-26\", \"name\": \"John\", \"time\": \"4pm-8pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"PM\", \"message\": \"a\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-14 19:02:52'),
(116,'patron',NULL,'9am–1pm',79,'VS-3CBFAD','a','2026-07-14 19:16:35','2026-07-31','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-31\", \"name\": \"John Deniel\", \"time\": \"9am–1pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 19:16:35'),
(117,'patron',NULL,'9am–1pm',79,'VS-0712E9','1','2026-07-14 19:24:00','2026-07-23','Villa I','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-23\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"1\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 19:24:00'),
(118,'patron',NULL,'4pm-8pm',79,'VS-B6FADB','a','2026-07-14 19:28:59','2026-07-16','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-16\", \"name\": \"asd\", \"time\": \"4pm-8pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"PM\", \"message\": \"a\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 19:28:59'),
(119,'patron',NULL,'9am–1pm',79,'VS-5AF2D4','a','2026-07-14 19:36:05','2026-07-21','Villa II','Debut Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-21\", \"name\": \"asdads\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 19:36:05'),
(120,'patron',NULL,'9am–1pm',79,'VS-53AADE','asd','2026-07-14 19:39:17','2026-07-20','Villa I','Kiddie Package','Beach',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-20\", \"name\": \"asd\", \"time\": \"9am–1pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Kiddie Package\", \"theme_motif\": \"Beach\", \"contact_number\": \"09123456789\"}','2026-07-14 19:39:17'),
(121,'patron',NULL,'9am–1pm',79,'VS-2563A7','a','2026-07-14 19:42:10','2026-07-19','Villa I','Birthday Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-19\", \"name\": \"aads\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-14 19:42:10'),
(122,'patron',NULL,'9am–1pm',79,'VS-ADF6D4','xd','2026-07-14 19:43:22','2026-07-17','Villa I','Birthday Package','Elegant',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-17\", \"name\": \"aa\", \"time\": \"9am–1pm\", \"email\": \"johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"xd\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09766736245\"}','2026-07-14 19:43:22'),
(123,'patron',NULL,'4pm-8pm',79,'VS-0CAD11','a','2026-07-15 18:46:56','2026-07-18','Villa I','Baptismal Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-18\", \"name\": \"John\", \"time\": \"4pm-8pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"PM\", \"message\": \"a\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-15 18:46:56'),
(124,'patron',NULL,'9am–1pm',79,'VS-B0A3F8','a','2026-07-15 19:07:07','2026-07-15','Villa I','Debut Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-15\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"a\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09123456789\"}','2026-07-15 19:07:07'),
(125,'patron',NULL,'9am–1pm',79,'VS-26A6C0','ads','2026-07-15 19:11:46','2026-07-13','Villa I','Wedding Package','Floral',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-13\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"ads\", \"event_type\": \"Wedding Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-15 19:11:46'),
(126,'patron',NULL,'9am–1pm',79,'VS-3E2E33','aa','2026-07-15 19:24:03','2026-07-09','Villa I','Baptismal Package','Floral',NULL,NULL,NULL,'Completed','{\"date\": \"2026-07-09\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"aa\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-16 05:49:27'),
(127,'patron',NULL,'4pm-8pm',78,'VS-E709EE','More chairs and more or proper ventilation','2026-07-15 19:29:50','2026-07-26','Elizabeth Hall','Standard Package','Modern',NULL,NULL,NULL,'Completed','{\"date\": \"2026-07-26\", \"name\": \"Guinevere D. Makatalon\", \"time\": \"4pm-8pm\", \"email\": \"olivermarcgasta@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"PM\", \"message\": \"More chairs and more or proper ventilation\", \"event_type\": \"Standard Package\", \"theme_motif\": \"Modern\", \"contact_number\": \"09488642607\"}','2026-07-16 05:50:12'),
(128,'patron',NULL,'11am–3pm',96,'VS-A87BAB','None test only','2026-07-18 11:16:42','2026-07-25','Elizabeth Hall','Wedding Package','Rustic',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-25\", \"name\": \"Eldie Gasta\", \"time\": \"11am–3pm\", \"email\": \"buenavistaeldie@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"AM\", \"message\": \"None test only\", \"event_type\": \"Wedding Package\", \"theme_motif\": \"Rustic\", \"contact_number\": \"09481061085\"}','2026-07-18 11:16:42'),
(129,'patron',NULL,'9am–1pm',97,'VS-60576B','N/A','2026-07-21 19:44:06','2026-07-23','Private Pool','Birthday Package','Elegant',NULL,NULL,NULL,'Pending','{\"date\": \"2026-07-23\", \"name\": \"Andrea Donatos\", \"time\": \"9am–1pm\", \"email\": \"dreadonatos@gmail.com\", \"venue\": \"Private Pool\", \"period\": \"AM\", \"message\": \"N/A\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"0909090909f\"}','2026-07-21 19:44:06');
/*!40000 ALTER TABLE `inquiry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_05_25_091731_create_posts_table',2),
(5,'2026_07_02_000000_create_guest_consents_table',2),
(6,'2026_07_02_010000_add_role_to_users_table',3),
(7,'2026_07_02_010100_add_label_and_email_to_guest_consents_table',3),
(8,'2026_07_03_000010_add_role_to_admin_table',4),
(9,'2026_07_04_000001_create_forms_table',5),
(10,'2026_07_04_000002_create_form_fields_table',5),
(11,'2026_07_04_000003_add_form_data_to_inquiry_and_reservation_tables',5),
(12,'2026_07_04_000004_create_admin_page_permissions_table',6),
(13,'2026_07_04_000005_add_status_to_payments_table',7),
(14,'2026_07_04_000006_add_inquiry_fk_to_payments_table',8),
(15,'2026_07_04_000007_create_payment_settings_table',9),
(16,'2026_07_04_135505_add_is_override_to_availabilities_table',10),
(17,'2026_07_04_142317_create_cancellation_requests_table',11),
(18,'2026_07_05_000001_create_waitlist_table',12),
(19,'2026_07_05_000002_add_reminder_sent_at_to_reservation_table',13),
(20,'2026_07_11_000001_add_password_reset_code_to_admin_table',14),
(21,'2026_07_03_000001_create_activity_log_table',15);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `inclusions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `image_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_2_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_3_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES
(2,'Wedding Package','An elegant setup tailored for weddings with full-service amenities.',25000.00,'[]','/images/wedding_package.jpg','/images/wedding_package2.jpg','/images/wedding_package3.jpg','2025-06-11 18:05:32','2025-06-25 02:56:58',NULL),
(3,'Debut Package','Celebrate 18 in style with stage, lights, and a memorable party setup.',100000.00,'[]','/images/debut_package.jpg','/images/debut_package2.jpg','/images/debut_package3.jpg','2025-06-11 18:05:45','2026-07-02 19:12:46',NULL),
(4,'Baptism Package','A wholesome and joyful setup for your babys special day.',15000.00,'[\"Theme decor\", \"Balloon setup\", \"Simple catering\"]','/images/baptism_package.jpg','/images/baptism_package2.jpg','/images/baptism_package3.jpg','2025-06-11 18:06:35','2025-06-11 18:06:35',NULL),
(5,'Kiddie Party Package','Fun and playful designs for an unforgettable kids celebration.',18000.00,'[\"Clown or mascot\", \"Games & prizes\", \"Theme cakes\"]','/images/kiddie_package.jpg','/images/kiddie_package2.jpg','/images/kiddie_package3.jpg','2025-06-11 18:06:42','2026-07-12 03:52:52','2026-07-12 03:52:52'),
(6,'Kiddie Package','Fun and playful designs for an unforgettable kids celebration.',200000.00,'[]','/storage/packages/SAarOuj3oAgkoIMubNapgagHV2NaxjXh85Z3SbbK.jpg',NULL,NULL,'2026-07-12 03:56:10','2026-07-12 03:56:21','2026-07-12 03:56:21'),
(7,'Kiddie Package','Test Description',20000.00,'[]','/storage/packages/0IIon8bgKZcBB1rr9wmDjQerzb7yuPG1Y7QJfWu9.jpg',NULL,NULL,'2026-07-12 04:52:59','2026-07-12 04:53:09','2026-07-12 04:53:09'),
(8,'no package','Testing Description',10000.00,'[]','/storage/packages/Aelp5sHIofKQQanECpQRCGI70z4vfctpw9jS0kNE.jpg',NULL,NULL,'2026-07-12 04:58:14','2026-07-12 04:58:37','2026-07-12 04:58:37');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `patron`
--

DROP TABLE IF EXISTS `patron`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patron` (
  `patron_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_number` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`patron_id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patron`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `patron` WRITE;
/*!40000 ALTER TABLE `patron` DISABLE KEYS */;
INSERT INTO `patron` VALUES
(5,'testing@gmail.com','tester1','09488642607','2025-03-28 12:41:07','2025-03-28 12:41:07'),
(6,'test@gmail.com','tester1','09488642607','2025-03-28 12:45:38','2025-03-28 12:45:38'),
(7,'test@gmail.com','tester1','09488642607','2025-03-28 12:51:31','2025-03-28 12:51:31'),
(8,'test@gmail.com','tester1','09488642607','2025-03-28 12:51:48','2025-03-28 12:51:48'),
(9,'test@gmail.com','tester1','09488642607','2025-03-28 12:52:16','2025-03-28 12:52:16'),
(10,'test@gmail.com','tester1','09488642607','2025-03-28 12:52:18','2025-03-28 12:52:18'),
(11,'test@gmail.com','tester1','09488642607','2025-03-28 12:56:10','2025-03-28 12:56:10'),
(12,'test@gmail.com','tester1','09488642607','2025-03-28 12:59:19','2025-03-28 12:59:19'),
(13,'test@gmail.com','tester1','09488642607','2025-03-28 12:59:22','2025-03-28 12:59:22'),
(14,'test@gmail.com','tester1','09488642607','2025-03-28 13:00:08','2025-03-28 13:00:08'),
(15,'test@gmail.com','tester1','09488642607','2025-03-28 13:01:14','2025-03-28 13:01:14'),
(16,'pretzel@gmail.com','Macky','1111111111111','2025-03-28 13:01:41','2025-03-28 13:01:41'),
(17,'testing@gmail.com','tester1','09488642607','2025-03-28 13:04:22','2025-03-28 13:04:22'),
(18,'testing@gmail.com','tester1','09488642607','2025-03-28 13:06:44','2025-03-28 13:06:44'),
(19,'testing@gmail.com','tester1','09488642607','2025-03-28 13:07:58','2025-03-28 13:07:58'),
(20,'testing@gmail.com','tester1','09488642607','2025-03-28 13:08:27','2025-03-28 13:08:27'),
(21,'testing@gmail.com','tester1','09488642607','2025-03-28 13:08:57','2025-03-28 13:08:57'),
(22,'testing@gmail.com','tester1','09488642607','2025-03-28 13:12:39','2025-03-28 13:12:39'),
(23,'testing@gmail.com','tester1','09488642607','2025-03-28 13:12:57','2025-03-28 13:12:57'),
(24,'testing@gmail.com','tester1','09488642607','2025-03-28 13:13:05','2025-03-28 13:13:05'),
(25,'testing@gmail.com','tester1','09488642607','2025-03-28 13:13:08','2025-03-28 13:13:08'),
(26,'testing@gmail.com','tester1','09488642607','2025-03-28 13:13:39','2025-03-28 13:13:39'),
(27,'akosi100@gmail.com','tester100','78787878787887','2025-03-28 13:14:35','2025-03-28 13:14:35'),
(28,'akosi100@gmail.com','tester100','78787878787887','2025-03-28 13:17:10','2025-03-28 13:17:10'),
(29,'akosi100@gmail.com','tester100','78787878787887','2025-03-28 13:17:15','2025-03-28 13:17:15'),
(30,'akosi100@gmail.com','tester100','78787878787887','2025-03-28 13:17:22','2025-03-28 13:17:22'),
(31,'akosi100@gmail.com','tester100','78787878787887','2025-03-28 13:17:33','2025-03-28 13:17:33'),
(32,'akosi100@gmail.com','tester100','78787878787887','2025-03-28 13:22:21','2025-03-28 13:22:21'),
(33,'testing1@gmail.com','ange','09876543211','2025-03-28 21:58:28','2025-03-28 21:58:28'),
(34,'testing1@gmail.com','ange','09876543211','2025-03-28 21:59:35','2025-03-28 21:59:35'),
(35,'gawa@gmail.com','gawa','875635875238','2025-04-05 04:38:24','2025-04-05 04:38:24'),
(36,'rsr@gmail.com','ange','09876543211','2025-04-05 04:49:29','2025-04-05 04:49:29'),
(37,'testing2@gmail.com','ange','09876543211','2025-04-05 10:11:43','2025-04-05 10:11:43'),
(38,'testing2@gmail.com','ange','09876543211','2025-04-05 10:15:15','2025-04-05 10:15:15'),
(39,'gawa@gmail.com','Lyka','09876543211','2025-04-07 16:21:30','2025-04-07 16:21:30'),
(40,'gawa@gmail.com','Lyka','09876543211','2025-04-07 16:24:40','2025-04-07 16:24:40'),
(41,'testing1@gmail.com','lyka rsr','09876543211','2025-04-25 18:33:29','2025-04-25 18:33:29'),
(42,'agoi@gmail.com','Agoi','12312312312','2025-05-26 15:20:28','2025-05-26 15:20:28'),
(43,'dos@gmail.com','uno','12345678912','2025-05-26 15:22:03','2025-05-26 15:22:03'),
(44,'isda@gmail.com','a','78945612301','2025-05-26 15:31:31','2025-05-26 15:31:31'),
(45,'isda@gmail.com','a','78945612301','2025-05-26 15:37:14','2025-05-26 15:37:14'),
(46,'naiinisna@gmail.com','naiinis ','12312312303','2025-05-26 15:38:49','2025-05-26 15:38:49'),
(47,'mamamo@gmail.com','Ma','12345678901','2025-06-05 15:22:51','2025-06-05 15:22:51'),
(48,'papamo@gmail.com','pa','78945612303','2025-06-05 15:43:27','2025-06-05 15:43:27'),
(49,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 11:55:38','2025-06-07 11:55:38'),
(50,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 11:57:54','2025-06-07 11:57:54'),
(51,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 11:58:00','2025-06-07 11:58:00'),
(52,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 11:59:02','2025-06-07 11:59:02'),
(53,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 12:02:15','2025-06-07 12:02:15'),
(54,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 12:02:46','2025-06-07 12:02:46'),
(55,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 12:04:29','2025-06-07 12:04:29'),
(56,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 12:05:56','2025-06-07 12:05:56'),
(57,'doe@gmail.com','Johny Doe','09123456789','2025-06-07 12:07:01','2025-06-07 12:07:01'),
(58,'amorgan@gmail.com','Arthur Morgan','(091) 234-5678','2025-06-09 16:28:05','2025-06-09 16:28:05'),
(59,'mbell@gmail.com','Micah Bell','(091) 234-5678','2025-06-09 18:17:28','2025-06-09 18:17:28'),
(60,'jmarston@gmail.com','Jack Marston','(091) 234-5678','2025-06-09 18:30:16','2025-06-09 18:30:16'),
(61,'lenny@gmail.com','Lenny','(094) 886-4260','2025-06-10 18:49:15','2025-06-10 18:49:15'),
(62,'cold@gmail.com','Colm O\'Driscoll','(094) 745-5874','2025-06-10 19:04:14','2025-06-10 19:04:14'),
(63,'jescuella@gmail.com','Javier Escuella','(321) 651-6156','2025-06-11 08:35:43','2025-06-11 08:35:43'),
(64,'charles@gmail.com','Charles','(689) 674-6546','2025-06-11 08:49:09','2025-06-11 08:49:09'),
(65,'sean@gmail.com','Sean','(879) 841-6515','2025-06-11 08:57:00','2025-06-11 08:57:00'),
(66,'djohn@gmail.com','Doe John','09123456789','2025-06-11 13:07:19','2025-06-11 13:07:19'),
(67,'aarceta@gmail.com','Aiah','(091) 234-5678','2025-06-11 13:09:33','2025-06-11 13:09:33'),
(68,'cvergara@gmail.com','Colet','09488642607','2025-06-11 13:26:49','2025-06-11 13:26:49'),
(69,'mricalde@gmail.com','Maloi','51819819849849','2025-06-12 06:52:38','2025-06-12 06:52:38'),
(70,'nerya@gmail.com','Arthur Nery','(094) 886-4260','2025-06-12 19:34:09','2025-06-12 19:34:09'),
(71,'adie@gmail.com','Adie','(161) 516-1616','2025-06-12 19:44:05','2025-06-12 19:58:11'),
(72,'tmonterde@gmail.com','Tj Monterde','(094) 886-4260','2025-06-12 19:59:56','2025-06-12 19:59:56'),
(73,'pelagiolander68@gmail.com','Lander Buelo Pelagio','09636775414','2025-06-17 05:26:12','2025-06-17 05:26:12'),
(74,'angelicalykarosario@gmail.com','Angelica Lyka Rosario','09099852202','2025-06-17 09:47:34','2025-06-17 09:47:34'),
(75,'marcolivergastagonzales@gmail.com','Marc Gasta','09099852202','2025-06-18 12:53:01','2025-06-18 12:53:01'),
(76,'kz@gmail.com','Kz Tandingan','(161) 516-1616','2025-06-19 03:19:05','2025-06-19 03:19:05'),
(77,'iwantcakex@gmail.com','Adie','(141) 598-4915','2025-06-19 03:20:52','2025-06-19 03:20:52'),
(78,'olivermarcgasta@gmail.com','Sean Mcguirre','09488642607','2025-06-19 06:17:24','2025-06-19 06:17:24'),
(79,'Johndenielescuro@gmail.com','John','09123456789','2026-07-01 17:05:51','2026-07-01 17:05:51'),
(80,'amael@gmail.com','johnjohn','09123456789','2026-07-02 16:52:18','2026-07-02 16:52:18'),
(81,'123123@adsasd','ASd','09123456789','2026-07-02 18:32:27','2026-07-02 18:32:27'),
(82,'123@nigga.com','123132','09123456789','2026-07-02 18:32:54','2026-07-02 18:32:54'),
(83,'cutehub0@gmail.com','Andrea','(091) 234-5678','2026-07-03 03:23:55','2026-07-03 03:23:55'),
(84,'johnny@gmail.com','John Doe','09766736245','2026-07-03 04:14:13','2026-07-03 04:14:13'),
(85,'123123@adsasd.com','jj','01203132132','2026-07-05 13:15:16','2026-07-05 13:15:16'),
(86,'johndeniel1818@gmail.com','aa','09123456789','2026-07-08 08:45:09','2026-07-08 08:45:09'),
(87,'asdsda@gmail.com','asdads','09123456789','2026-07-09 23:03:49','2026-07-09 23:03:49'),
(88,'aksmdamsd@gmail.com','asdsad','09123456788','2026-07-09 23:07:39','2026-07-09 23:07:39'),
(89,'fuckyou@gmail.com','asddas','09123456789','2026-07-09 23:09:55','2026-07-09 23:09:55'),
(90,'123123@adsas.com','asddas','09123456789','2026-07-09 23:14:34','2026-07-09 23:14:34'),
(91,'ad@gmail.com','asdads','09123456789','2026-07-09 23:19:35','2026-07-09 23:19:35'),
(92,'test@example.com','Test User','09171234567','2026-07-12 13:57:26','2026-07-12 13:57:26'),
(93,'test2@example.com','Test User 2','09179876543','2026-07-12 13:58:38','2026-07-12 13:58:38'),
(94,'admin-test@example.com','Admin Test User','09171112222','2026-07-12 14:01:05','2026-07-12 14:01:05'),
(95,'patron-test@example.com','Patron Test','09179998888','2026-07-12 14:11:32','2026-07-12 14:11:32'),
(96,'buenavistaeldie@gmail.com','Eldie Gasta','09481061085','2026-07-18 11:16:42','2026-07-18 11:16:42'),
(97,'dreadonatos@gmail.com','Andrea Donatos','0909090909f','2026-07-21 19:44:06','2026-07-21 19:44:06');
/*!40000 ALTER TABLE `patron` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payment_settings`
--

DROP TABLE IF EXISTS `payment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payment_settings` WRITE;
/*!40000 ALTER TABLE `payment_settings` DISABLE KEYS */;
INSERT INTO `payment_settings` VALUES
(1,'gcash_account_name','Elizabeth R.',NULL,NULL),
(2,'gcash_mobile_number','09062236120',NULL,NULL),
(3,'gcash_qr_path','images/gcash.jpg',NULL,NULL),
(4,'bank_name','BPI Savings Bank',NULL,NULL),
(5,'bank_account_name','Ernesto Rafael Jr. and/or Elizabeth Rafael',NULL,NULL),
(6,'bank_account_number','8230001538',NULL,NULL),
(7,'cash_instructions','Pay in person at the Villa office. Provide your tracking code at the counter.',NULL,NULL),
(8,'contact_phone','(+63) 912 345 6789',NULL,NULL),
(9,'contact_email','villasalud.events@gmail.com',NULL,NULL);
/*!40000 ALTER TABLE `payment_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `tracking_code` varchar(50) NOT NULL,
  `reservation_code` varchar(255) NOT NULL,
  `inquiry_id` int DEFAULT NULL,
  `receipt_path` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected','refunded') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `tracking_code` (`tracking_code`),
  KEY `payments_inquiry_id_foreign` (`inquiry_id`),
  CONSTRAINT `payments_inquiry_id_foreign` FOREIGN KEY (`inquiry_id`) REFERENCES `inquiry` (`inquiry_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,'Lander Pelagio','full','gcash','VS-144560-7175','VS-44A5A2',55,'receipts/I6vY4zKoRkUfnpyY8DR9pa2PirKMga6dJgXvBuAp.png','pelagiolander68@gmail.com','pending','2025-06-16 23:16:00','2026-07-04 13:23:28'),
(2,'Lander Pelagio','full','gcash','VS-144700-6670','VS-44A5A2',55,'receipts/R7cFMNN7HkCou4IxRWMu2cVvFzoLUnohVNnXy0Qw.png','pelagiolander68@gmail.com','pending','2025-06-16 23:18:20','2026-07-04 13:23:28'),
(3,'Sean Mcguirre','half','gcash','VS-313950-1253','VS-44A1F6',71,'receipts/SjT73YWjAIPhDY36wBc5WaqhkwXbJbEM4r3Oe8Nu.png','olivermarcgasta@gmail.com','pending','2025-06-18 22:19:10','2026-07-04 13:23:28'),
(4,'daphy','full','gcash','VS-322573-5009','VS-E14389',72,'receipts/61uxiL4Us5IkoCulmBYwziVNKzbiIoymineNuHej.png','iwantcakex@gmail.com','pending','2025-06-19 00:42:53','2026-07-04 13:23:28'),
(5,'John','full','gcash','VS-871195-9553','VS-B4CE47',83,'receipts/fd01Z2EYAWkiSwLJQ18pQ11rifWBTILjalVPtzkn.jpg','johndenielescuro@gmail.com','rejected','2026-07-12 07:46:35','2026-07-13 07:56:38');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `reserve_id` int NOT NULL AUTO_INCREMENT,
  `inquiry_id` int NOT NULL,
  `patron_id` int NOT NULL,
  `admin_id` int DEFAULT NULL,
  `status` enum('active','cancelled','completed') DEFAULT 'active',
  `form_data` json DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` text,
  `venue` varchar(255) DEFAULT NULL,
  `event_type` varchar(255) DEFAULT NULL,
  `theme_motif` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `event_reminder_sent_at` timestamp NULL DEFAULT NULL,
  `payment_reminder_sent_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`reserve_id`),
  KEY `admin_id` (`admin_id`),
  KEY `fk_res_patron` (`patron_id`),
  KEY `fk_res_inquiry` (`inquiry_id`),
  CONSTRAINT `fk_res_inquiry` FOREIGN KEY (`inquiry_id`) REFERENCES `inquiry` (`inquiry_id`),
  CONSTRAINT `fk_res_patron` FOREIGN KEY (`patron_id`) REFERENCES `patron` (`patron_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`inquiry_id`) REFERENCES `inquiry` (`inquiry_id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`patron_id`) REFERENCES `patron` (`patron_id`),
  CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES
(3,24,38,16,'active',NULL,'2025-04-15','07:12:00','2025-05-30 05:53:32','want to inquiry','Villa I','Baptismal Package','Floral','2026-07-05 05:30:02',NULL,'2026-07-05 05:30:02'),
(4,17,26,16,'active',NULL,'2025-04-05','21:04:00','2025-05-30 05:53:35','sup','Villa I',NULL,'Floral','2026-07-05 05:30:04',NULL,'2026-07-05 05:30:04'),
(5,20,34,16,'active',NULL,'2025-03-31','09:00:00','2025-05-30 05:53:37','mama mo','Villa I','Birthday Package','Beach','2026-07-05 05:30:06',NULL,'2026-07-05 05:30:06'),
(6,7,16,16,'active',NULL,'2025-03-21','05:06:00','2025-05-30 05:53:38','Kumain kana lab?','Villa I',NULL,'Floral','2026-07-05 05:30:07',NULL,'2026-07-05 05:30:07'),
(7,18,32,16,'active',NULL,'2025-04-10','23:20:00','2025-05-30 05:53:40','testing 123','Villa I','Baptismal Package','Floral','2026-07-05 05:30:09',NULL,'2026-07-05 05:30:09'),
(8,48,66,NULL,'active',NULL,'2025-06-20','2pm–4pm','2025-06-12 22:22:41','testting 8','Others','Others','Others','2026-07-05 05:30:10',NULL,'2026-07-05 05:30:10'),
(9,51,69,NULL,'cancelled',NULL,'2025-06-25','9am–11am','2025-06-12 23:27:54','Taru tatu taru','Villa I','Baptismal Package','Elegant','2026-07-04 06:31:36',NULL,NULL),
(10,63,74,NULL,'active',NULL,'2025-06-28','5pm–9pm','2025-06-17 12:31:33','Request for RGB light and additional ten (10) tables and 5 chairs each. Thank you!','Elizabeth Hall','Debut Package','Modern','2026-07-05 05:30:12',NULL,'2026-07-05 05:30:12'),
(11,70,77,NULL,'active',NULL,'2025-09-09','9am–11am','2025-06-19 03:21:53','More drinks and chairs','Others','Others','Others','2026-07-05 05:30:14',NULL,'2026-07-05 05:30:14'),
(12,71,78,NULL,'active',NULL,'2025-06-26','9am–1pm','2025-06-19 06:18:28','None','Villa II','Debut Package','Rustic','2026-07-05 05:30:15',NULL,'2026-07-05 05:30:15'),
(13,80,83,NULL,'active',NULL,'2026-07-05','10am–12pm','2026-07-03 03:51:05','Purple Pleaseeee','Villa II','Birthday Package','Others','2026-07-03 03:51:05',NULL,NULL),
(15,96,91,NULL,'active','{\"date\": \"2026-07-30\", \"name\": \"asdads\", \"time\": \"9am–1pm\", \"email\": \"ad@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"asd\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09123456789\"}','2026-07-30','9am–1pm','2026-07-10 13:24:36','asd','Villa I','Baptismal Package','Elegant','2026-07-10 13:24:36',NULL,NULL),
(16,109,84,NULL,'active','{\"date\": \"2026-08-06\", \"name\": \"John\", \"time\": \"9am–11am\", \"email\": \"johnny@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"N/a\", \"event_type\": \"Kiddie Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-08-06','9am–11am','2026-07-12 07:25:44','N/a','Villa I','Kiddie Package','Floral','2026-07-12 07:25:44',NULL,NULL),
(17,83,79,NULL,'cancelled','{\"date\": \"2026-07-07\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"yes\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09766736245\"}','2026-07-07','9am–1pm','2026-07-12 07:41:07','yes','Villa I','Baptismal Package','Floral','2026-07-14 08:34:23',NULL,NULL),
(18,110,84,NULL,'active','{\"date\": \"2026-08-17\", \"name\": \"John\", \"time\": \"10am–2pm\", \"email\": \"johnny@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"AM\", \"message\": \"Please be cute!\", \"event_type\": \"Kiddie Package\", \"theme_motif\": \"Beach\", \"contact_number\": \"09766736245\"}','2026-08-17','10am–2pm','2026-07-13 08:08:34','Please be cute!','Elizabeth Hall','Kiddie Package','Beach','2026-07-13 08:08:34',NULL,NULL),
(19,111,79,NULL,'cancelled','{\"date\": \"2026-07-16\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"Yes\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-16','9am–1pm','2026-07-14 08:36:00','Yes','Villa I','Baptismal Package','Floral','2026-07-14 08:37:43',NULL,NULL),
(20,106,94,NULL,'active','{\"date\": \"2026-09-10\", \"name\": \"Admin Test User\", \"time\": \"10am–12pm\", \"email\": \"admin-test@example.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"Admin test reservation\", \"event_type\": \"Birthday Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09175556666\"}','2026-09-10','10am–12pm','2026-07-14 08:43:18','Admin test reservation','Villa I','Birthday Package','Elegant','2026-07-14 08:43:18',NULL,NULL),
(21,105,95,NULL,'active','{\"date\": \"2026-08-25\", \"name\": \"Patron Test\", \"time\": \"9am–1pm\", \"email\": \"patron-test@example.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"Test patron toast\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Elegant\", \"contact_number\": \"09179998888\"}','2026-08-25','9am–1pm','2026-07-14 08:50:36','Test patron toast','Villa II','Debut Package','Elegant','2026-07-14 08:50:36',NULL,NULL),
(22,104,91,NULL,'cancelled','{\"date\": \"2026-07-15\", \"name\": \"aads\", \"time\": \"9am–11am\", \"email\": \"ad@gmail.com\", \"venue\": \"Villa II\", \"period\": \"AM\", \"message\": \"ds\", \"event_type\": \"Debut Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-15','9am–11am','2026-07-14 08:54:10','ds','Villa II','Debut Package','Floral','2026-07-14 08:54:28',NULL,NULL),
(23,126,79,NULL,'active','{\"date\": \"2026-07-09\", \"name\": \"John\", \"time\": \"9am–1pm\", \"email\": \"Johndenielescuro@gmail.com\", \"venue\": \"Villa I\", \"period\": \"AM\", \"message\": \"aa\", \"event_type\": \"Baptismal Package\", \"theme_motif\": \"Floral\", \"contact_number\": \"09123456789\"}','2026-07-09','9am–1pm','2026-07-16 05:49:27','aa','Villa I','Baptismal Package','Floral','2026-07-16 05:49:27',NULL,NULL),
(24,127,78,NULL,'active','{\"date\": \"2026-07-26\", \"name\": \"Guinevere D. Makatalon\", \"time\": \"4pm-8pm\", \"email\": \"olivermarcgasta@gmail.com\", \"venue\": \"Elizabeth Hall\", \"period\": \"PM\", \"message\": \"More chairs and more or proper ventilation\", \"event_type\": \"Standard Package\", \"theme_motif\": \"Modern\", \"contact_number\": \"09488642607\"}','2026-07-26','4pm-8pm','2026-07-16 05:50:12','More chairs and more or proper ventilation','Elizabeth Hall','Standard Package','Modern','2026-07-16 05:50:12',NULL,NULL);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('DCl40C8r3FTTgUKKNTMt5k2XoGRrQWv8rvgxLEnu',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoieFBEcE5lS0Y3V3BoTUt2aEZnTXI0QUVRZWpPTU5jUDdwakpGdnV3VCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9ob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1765801755),
('uGVXKk5A80geGL1vJgJNiVz9Bro8C0RKeOyKwVqC',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUDV1QWprTWI2WGhSZUgxZ1MzNU5ma0pmZlBxMVB6cnREMG9CVVRZSSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fX0=',1750850298);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'guest',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Test User','test@example.com',NULL,'$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','guest',NULL,'2026-07-01 21:57:08','2026-07-10 10:24:33'),
(2,'IT Admin','it@villasalud.test',NULL,'$2y$12$x32SGrMDjopG/8g2uR0yuOINqbGbzNrCjt2yjr0woCxuIj8Cw0G4y','it',NULL,'2026-07-01 21:57:08','2026-07-10 10:24:33');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `waitlist`
--

DROP TABLE IF EXISTS `waitlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `waitlist` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `patron_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `patron_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_date` date NOT NULL,
  `status` enum('waiting','notified','claimed','expired') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
  `notified_at` timestamp NULL DEFAULT NULL,
  `claimed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `waitlist_patron_email_requested_date_unique` (`patron_email`,`requested_date`),
  KEY `waitlist_requested_date_status_index` (`requested_date`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `waitlist`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `waitlist` WRITE;
/*!40000 ALTER TABLE `waitlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `waitlist` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping routines for database 'railway'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-07-22 19:02:52
